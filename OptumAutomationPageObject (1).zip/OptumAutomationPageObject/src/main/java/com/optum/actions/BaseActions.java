package com.optum.actions;
/**
 * @author Igor Verkhosh - September 2018
 */

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import com.optum.utilities.BasePage;
import com.optum.utilities.DataIO;


public class BaseActions extends BasePage {
	protected static String currentUrl = null;
	protected WebDriver driver;
	public BaseActions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public void logTestMethod(){
		logMessage("hello this is log test");
	}

	/**
	 * This method is to fetch current browser URL and save it to test data file
	 * @param property
	 * @param fileName
	 */
	public void getCurrentURLAndSaveInDataFile(String property, String fileName){
		currentUrl = getCurrentURL();
		DataIO.updateDataInPropertiesFile(property, currentUrl, fileName);
	}
	
	/**
	 * this method is to refresh the browser session as per its pre-stage
	 * @param property
	 * @param fileName
	 */

	// This is a new method to refreshLaunchingURL - which should work for classic and lightning
	public void refeshLaunchingURL(String property, String fileName, String className){
		System.out.println("***************** Test "+ className + " Executed ****************");
		String[] URL = currentUrl.trim().split(".com");
		String LT_URL = getCurrentURL();
		if (LT_URL.contains("lightning")) {
			if(isElementPresent("Logged_In_As_User_txt_LT", "HomePage")){
				navigateToURL(URL[0].trim()+".com/secur/logout.jsp");  // https://na49.lightning.force.com/secur/logout.jsp
				navigateToURL(currentUrl);
			}
		}else {
			try{
				navigateToURL(currentUrl);
				if(isElementPresent("Logged_In_As_User_txt", "HomePage")){
					navigateToURL(URL[0].trim()+".com/secur/logout.jsp");  // https://na49.lightning.force.com/secur/logout.jsp
					navigateToURL(currentUrl);
				}
				if (!isElementPresent("GlobalSearch_button", "HomePage")) {
					driver.manage().deleteAllCookies();
					navigateToURL(currentUrl);
					System.out.println("@@@@@@ ---- Login Page Displayed");
					new LoginPageActions(driver).PERFORM_LOGIN_IN_OPTUM(DataIO.get("admin_email", "LoginData"), DataIO.get("admin_password", "LoginData"));
		
				}

			}catch(Exception e){
				System.out.println("Exception in refreshing the session");
			}		
		}
	}
// This is original method to refreshLaunchingURL - which is working for classic	
//	public void refeshLaunchingURL(String property, String fileName, String className){
//		System.out.println("***************** Test "+ className + " Executed ****************");
//		String[] URL = currentUrl.trim().split(".com");
//		try{
//			navigateToURL(currentUrl);
//			if(isElementPresent("Logged_In_As_User_txt", "HomePage")){
//				navigateToURL(URL[0].trim()+".com/secur/logout.jsp");
//				navigateToURL(currentUrl);
//			}
//			if (!isElementPresent("GlobalSearch_button", "HomePage")) {
//				driver.manage().deleteAllCookies();
//				navigateToURL(currentUrl);
//				System.out.println("@@@@@@ ---- Login Page Displayed");
//				new LoginPageActions(driver).PERFORM_LOGIN_IN_OPTUM(DataIO.get("admin_email", "LoginData"), DataIO.get("admin_password", "LoginData"));
//	
//			}
//
//		}catch(Exception e){
//			System.out.println("Exception in refreshing the session");
//		}
//	}

	public void getStartTime() {		
		System.out.println("Test Start Time: " + getCurrentDateTime("MM/dd/yyyy HH:mm:ss"));
	}

	public void getEndTime() {
		System.out.println("Test End Time: " + getCurrentDateTime("HH:mm:ss"));
		
	}
	
	/**
	This method is to search for user using Global Search
	 */
	public void search_for_GlobalSearch(String GlobalSearchFor) {
		hardWait(3);
		writeTextInto("GlobalSearch_txtbox", "HomePage", GlobalSearchFor);
		click("GlobalSearch_button", "HomePage");
}
	
	/**
	This method is to search for user using Global Search
	 */
	public void search_for_User(String SearchName) {
		hardWait(3);
		writeTextInto("GlobalSearch_txtbox", "HomePage", DataIO.get(SearchName, "LoginTestData"));
		click("GlobalSearch_button", "HomePage");
}
	
	/**
	This method is to login as user after user searched.
	 */
	public void login_As_User(String username) {
		username = DataIO.get(username, "LoginTestData");
		hardWait(2);
		click("searchedUser_link","HomePage");
		click("Downarrow","HomePage");
		click("userdetail_link","HomePage");
		click("Login_button","HomePage");
		hardWait(2);
		System.out.println("Logged in as: " + username);
	}

	public void click_on_Tab(String tabName) {
		if (isElementPresent("AppLauncher_button", "HomePage")) {
			click(tabName+"_LT", "HomePage");
		}
		else {
			click(tabName, "HomePage");}
		hardWait(2);
		System.out.println("Clicked on: " + tabName);
		}
	
	public static long addRandomNumber(int numberDigits) {
		long randomNumber = Math.round(Math.random() * numberDigits);
		return randomNumber;
	}
	

}