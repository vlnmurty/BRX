package com.optum.testcases.Assessment_MS_Initial;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.optum.setup.BaseTest;

public class Add_Prescription_to_ExistingAccount_PHQ_2_Email_Yes extends BaseTest {

	@AfterClass
	public void RefreshSession() {
		tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
		tsi.baseAction.getEndTime();
	}

	@BeforeClass
	public void getStartTime() {
		tsi.baseAction.getStartTime();
	}

	@Test // (priority=5, enabled=true, invocationCount=1)
	public void addNewPrescriptionToExistingAccount() {
		tsi.prescriptionPage.addNewPrescriptionToExistingPatient();
	}

//		@Test (dependsOnMethods= "addNewPrescriptionToExistingAccount")//(priority = 3, enabled = true, invocationCount = 1)
//		public void createNewAssessment() {
//			tsi.assessmentPage.createNewAssessment("1", "1", "Yes");
//		}
//
//		@Test (dependsOnMethods= "createNewAssessment") //(priority = 4, enabled = true, invocationCount = 1)
//		public void verifyCreatedTasks() {
//			tsi.assessmentPage.openAssessmentPatientAccount();
//			tsi.accountPage.readTasksList();
//		}

}