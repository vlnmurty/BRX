package com.optum.setup;
/**
 * @author Igor Verkhosh
 */

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import com.optum.actions.AccountsPageActions;
import com.optum.actions.AccountsPageActionsLT;
import com.optum.actions.AdverseEventPageActionLT;
import com.optum.actions.BaseActions;
import com.optum.actions.HomePageActions;
import com.optum.actions.LoginPageActions;
import com.optum.actions.PrescriptionPageActionLT;
import com.optum.actions.PrescriptionPageActions;
import com.optum.actions.AllTabsPageActions;
import com.optum.actions.AppLauncherPageAction;
import com.optum.actions.AssessmentPageActions;
import com.optum.actions.SetupPageActions;
import com.optum.utilities.BasePage;
import com.optum.utilities.DataIO;
import org.apache.log4j.Logger;

public class TestSessionInitiator {
	
	public TestSessionInitiator() {
		if (driver == null) {
			launchBrowserSession();
		}
		verificationErrors = new StringBuffer();
	}

public static WebDriver driver = null;
private WebDriverFactory wdf = new WebDriverFactory();

//Define all the page objects will null
public BasePage baseui = null;
public HomePageActions homepage = null;
public BaseActions baseAction = null;
public LoginPageActions loginPage = null;
public AccountsPageActions accountPage = null;
public AllTabsPageActions allTabsPage=null;
public SetupPageActions SetupPage=null;
public PrescriptionPageActions prescriptionPage = null;
public AssessmentPageActions assessmentPage = null;
public AppLauncherPageAction appLauncherPage = null;
public AccountsPageActionsLT accountsPageLT = null;
public PrescriptionPageActionLT prescriptionPageLT = null;
public AdverseEventPageActionLT adverseEventPageLT = null;
//public ExtentReports extentReports = ExtentManager.getInstance();
//public ExtentTest test;
public Logger log = Logger.getLogger("devpinoyLogger");


/**
 * Initialize all the page objects for all action classes
 */
private void _initActions(){
	
	baseAction = new BaseActions(driver);
	homepage = new HomePageActions(driver);
	loginPage = new LoginPageActions(driver);
	accountPage = new AccountsPageActions(driver);
	allTabsPage = new AllTabsPageActions(driver);
	SetupPage = new SetupPageActions(driver);
	prescriptionPage = new PrescriptionPageActions(driver);
	assessmentPage = new AssessmentPageActions(driver);
	appLauncherPage = new AppLauncherPageAction(driver);
	accountsPageLT = new AccountsPageActionsLT(driver);
	prescriptionPageLT = new PrescriptionPageActionLT(driver);
	adverseEventPageLT = new AdverseEventPageActionLT(driver);
}

/**
 * Launching browser instance
 */
private void launchBrowserSession(){
	_browserConfig();
	_initActions();	
}

/**
 * This method is to configure the browser setting.
 */
private void _browserConfig(){
	driver = wdf.getBrowser();	
	driver.manage().deleteAllCookies();
	if(DataIO.get("localBrowserName", "Config").equalsIgnoreCase("Chrome")){
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
	}
	driver.manage().timeouts().implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")), TimeUnit.SECONDS);
}

/**
 * This keyword is used to launch applications that use authentication
 * to validate user
 * @param applicationpath
 * @param authUser
 * @param authPed
 */
public void launchApplication(String applicationpath, String authUser, String authPwd, String browser) {
	System.out.println("browser name=="+ browser);
	if(!browser.equalsIgnoreCase("IE")){
		applicationpath = applicationpath.replace(
				"http://",
				"http://" + authUser.replaceAll("@", "%40") + ":"
						+ authPwd.replaceAll("@", "%40") + "@");
		Reporter.log("The application url is :- " + applicationpath, true);
		driver.get(applicationpath);
	}
}

public void getURL(String URL){
	driver.get(URL);
}

public void close(){
	try{ 
		driver.quit();
		if (driver != null) { 
			driver.quit(); 
		} 
		System.out.println(driver);
	}catch(Exception e) { 
	}
}

public void verifyTrue(boolean condition, String test) {
	try {
		Assert.assertTrue(condition,test);
	} catch (Error e) {
		verificationErrors.append(e);
		Reporter.log("failed");
	}
}

private StringBuffer verificationErrors;


}