package com.optum.setup;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.optum.utilities.DataIO;

/**
 * @author Igor Verkhosh
 */

public class WebDriverFactory {

	protected static WebDriver driver = null;
	protected static DesiredCapabilities capability = new DesiredCapabilities();
    private RemoteWebDriver remoteDriver;

	/**
	 * This method is to return driver instance for given browserName
	 * @param browserName
	 * @return
	 */
	private WebDriver setLocalBrowser() {

		String browserName = DataIO.get("localBrowserName", "Config").toUpperCase();
		String driversLocation = System.getProperty("user.dir")+File.separator+"src"+File.separator +"test" +File.separator+ "resources"+File.separator+"drivers"+File.separator;
		switch (browserName) {
		case "FIREFOX":
			driver = getFirefoxDriver(driversLocation + "geckodriver.exe");
			break;
		case "FF":
			driver = getFirefoxDriver(driversLocation + "geckodriver.exe");
			break;
		case "CHROME":
			if(System.getProperty("os.name").startsWith("Mac")){
				driver = getChromeDriver(driversLocation + "chromedriver");
			}
			else {
				driver = getChromeDriver(driversLocation + "chromedriver.exe");
			}
			break;
		case "INTERNETEXPLORER":
			driver = getInternetExplorerDriver(driversLocation + "IEDriverServer.exe");
			break;
		case "IE":
			driver = getInternetExplorerDriver(driversLocation + "IEDriverServer.exe");
			break;
		case "HEADLESS":
			driver = getHtmlUnitDriver();
			break;	
		default:
			driver = getFirefoxDriver(driversLocation + "geckodriver.exe");
			break;
		}

		return driver;
	}

	/**
	 * get Browser driver as per the config file
	 * @return
	 */
	public WebDriver getBrowser() {
		if (DataIO.get("serverType", "Config").equalsIgnoreCase("local")) {
			driver = setLocalBrowser();
		} else if (DataIO.get("serverType", "Config").equalsIgnoreCase("remote")) {
			driver = setRemoteDriver();
		}
		return driver;
	}

	/**
	 * Launching firefox browser
	 * @return FirefoxDriver
	 */
	private WebDriver getFirefoxDriver(String driverPath) {
		FirefoxProfile profile = new FirefoxProfile();
		System.setProperty("webdriver.firefox.marionette",driverPath);
		profile.setPreference("browser.cache.disk.enable", false);
		profile.setPreference("network.automatic-ntlm-auth.allow-non-fqdn", true);
		
		return new FirefoxDriver();
	}
	
	/**
	 * @param driverPath
	 * @return
	 */
	private WebDriver getChromeDriver(String driverPath) {
		System.setProperty("webdriver.chrome.driver", driverPath);
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("--disable-extensions");
		options.addArguments("--disable-infobars");
		return new ChromeDriver(options);
	}

	/**
	 * this Method is for return New IE driver instance
	 * @param driverPath
	 * @return IE driver instance
	 */
	private WebDriver getInternetExplorerDriver(String driverPath) {
		System.setProperty("webdriver.ie.driver", driverPath);
		return new InternetExplorerDriver();
	}

	/**
	 * @param driverPath
	 * @return
	 */
	private WebDriver getHtmlUnitDriver() {
		HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.CHROME);
		return driver;
	}
	
    public static void highlightElement(WebElement element) {
        for (int i = 0; i <2; i++) {
            JavascriptExecutor js = (JavascriptExecutor) WebDriverFactory.getDriver();
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: yellow; border: 2px solid yellow;");
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
            }
        }
//New Getter and Setter to work with driver
	public static WebDriver getDriver() {
		return driver;
	}

	public static void setDriver(WebDriver driver) {
		WebDriverFactory.driver = driver;
	}
	
	private WebDriver setRemoteDriver() {
		DesiredCapabilities cap = null;
		String browser = DataIO.get("remoteBrowserName", "Config");
		if (browser.equalsIgnoreCase("firefox")) {
			cap = DesiredCapabilities.firefox();
			cap.setCapability("platform",
					DataIO.get("platform", "Config"));
			cap.setCapability("version",
					DataIO.get("version", "Config"));
			cap.setCapability("name", "Workday Automation");

		} else if (browser.equalsIgnoreCase("chrome")) {
			cap = DesiredCapabilities.chrome();
			cap.setCapability("platform",
					DataIO.get("platform", "Config"));
			cap.setCapability("version",
					DataIO.get("version", "Config"));
			cap.setCapability("name", "Workday Automation");

		} else if (browser.equalsIgnoreCase("Safari")) {
			cap = DesiredCapabilities.safari();
		} else if ((browser.equalsIgnoreCase("ie"))
				|| (browser.equalsIgnoreCase("internetexplorer"))
				|| (browser.equalsIgnoreCase("internet explorer"))) {
			cap = DesiredCapabilities.internetExplorer();
			cap.setCapability("platform",
					DataIO.get("platform", "Config"));
			cap.setCapability("version",
					DataIO.get("version", "Config"));
		}
		String seleniuhubaddress = DataIO.get("remoteURL", "Config");
		URL selserverhost = null;
		try {
			selserverhost = new URL(seleniuhubaddress);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		 cap.setJavascriptEnabled(true);
		
		remoteDriver = new RemoteWebDriver(selserverhost, cap);
		remoteDriver.setFileDetector(new LocalFileDetector());
		
		return remoteDriver;
		
	}	

	public static void quitBrowser(){	
		driver.quit();	
	}
}

