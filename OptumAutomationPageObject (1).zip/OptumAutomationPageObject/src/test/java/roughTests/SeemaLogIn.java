package roughTests;

import java.util.HashMap;
import java.util.Map;

//import java.io.File;
//import java.util.HashMap;
//import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.chrome.ChromeOptions;

public class SeemaLogIn {

		public static void main(String[] args) {

//			String driversLocation = System.getProperty("user.dir") + "//src//test//resources//drivers";
//			System.setProperty("webdriver.chrome.driver", driversLocation);
//			driver = getChromeDriver(driversLocation + "chromedriver.exe");
//			
//			WebDriver driver = new ChromeDriver();
//			driver.get("test.salesforce.com");
//			driver.getCurrentUrl();
//			
//			driver.quit();
//	
//		}
			
			System.out.println(System.getProperty("user.dir"));
			String driversLocation = System.getProperty("user.dir") + "\\src\\test\\resources\\drivers\\chromedriver.exe";
			System.out.println(driversLocation);
			System.setProperty("webdriver.chrome.driver", driversLocation);
			WebDriver driver = new ChromeDriver();
			//driver = getChromeDriver(driversLocation + "chromedriver");
			driver.get("https://test.salesforce.com");
			driver.getCurrentUrl();
			driver.quit();
	}
			
		
//		private static WebDriver getChromeDriver(String driverPath) {
//			System.setProperty("webdriver.chrome.driver", driverPath);
//			Map<String, Object> prefs = new HashMap<String, Object>();
//			prefs.put("profile.default_content_setting_values.notifications", 2);
//			prefs.put("credentials_enable_service", false);
//			prefs.put("profile.password_manager_enabled", false);
//			ChromeOptions options = new ChromeOptions();
//			options.setExperimentalOption("prefs", prefs);
//			options.addArguments("--disable-extensions");
//			options.addArguments("--disable-infobars");
//			return new ChromeDriver(options);
//		}

}

//package optumTests;
//
//import java.io.File;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//
//public class LoginTest {
//
//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		String driversLocation = System.getProperty("user.dir") + "//src//test//resources//drivers";
//		System.setProperty("webdriver.chrome.driver", driversLocation);
//		//driver = getChromeDriver(driversLocation + "chromedriver");
//		driver.get("test.salesforce.com");
//		driver.getCurrentUrl();
//
//	}
//	
//	private static WebDriver getChromeDriver(String driverPath) {
//		System.setProperty("webdriver.chrome.driver", driverPath);
//		Map<String, Object> prefs = new HashMap<String, Object>();
//		prefs.put("profile.default_content_setting_values.notifications", 2);
//		prefs.put("credentials_enable_service", false);
//		prefs.put("profile.password_manager_enabled", false);
//		ChromeOptions options = new ChromeOptions();
//		options.setExperimentalOption("prefs", prefs);
//		options.addArguments("--disable-extensions");
//		options.addArguments("--disable-infobars");
//		return new ChromeDriver(options);
//	}
//
//}