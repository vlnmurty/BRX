package roughTests;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.concurrent.ThreadLocalRandom;

import com.optum.utilities.DataIO;

public class randomNumbers {

	public static void main(String[] args) {
		String FirstName = DataIO.get("FirstName", "AccountsTestData")+(addRandomNumberToString(9999));
		System.out.println("FirstName: " + FirstName);
		String LastName = DataIO.get("LastName", "AccountsTestData") + (addRandomNumberToString(99999)); 
		System.out.println("LastName: " + LastName );
		String SourceRx = null;
		String RxNumber = "Rx";
		String ScriptMedReferalNum = "SM";
		String PharmacyCode = "00";
		String DateofBirth = null;
		
		int SourceDataSelection = (int) Math.round(Math.random());
		
		if (SourceDataSelection != 1) {
			SourceRx = "IRIS";
			RxNumber = RxNumber + addRandomNumberToString(89999999);
			System.out.println("SourceData: " + SourceRx);
			System.out.println("Rx Number: " + RxNumber);
		}else {
			SourceRx = "ScriptMed";
			ScriptMedReferalNum = ScriptMedReferalNum + addRandomNumberToString(89999999);
			PharmacyCode = addRandomNumberToString(25);
			System.out.println("SourceData: " + SourceRx);
			System.out.println("ScriptMed Patient ID: " + ScriptMedReferalNum + " Pharmacy Code: " + PharmacyCode);
		}
		
		System.out.println(getPastDateBySubtractingGivenDays(-5));
		
//	    for (int i = 45; i > 1; i--) {
//	        System.out.println(getPastDateBySubtractingGivenDays(i));
//	    }
	    
	}
	
	public static String addRandomNumberToString(int numberDigits) {
		String randomNumber = Long.toString(Math.round(Math.random() * numberDigits));
		return randomNumber;
		
	}

	public static String randomDOB() {

		int yyyy = random(1930, 1999);
		int mm = random(1, 12);
		int dd = random(1, 28); // will set it later depending on year and month
		return Integer.toString(mm) + '/' + Integer.toString(dd) + '/' + Integer.toString(yyyy);
	}

	public static int random(int lowerBound, int upperBound) {
		return (lowerBound + (int) Math.round(Math.random() * (upperBound - lowerBound)));
	}
	
	public static String getPastDateBySubtractingGivenDays(int pastDateInDays) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, pastDateInDays);
		return sdf.format(cal.getTime()).trim();
	}
	

}
