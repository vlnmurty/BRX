package com.optum.utilities;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

//import java.util.Iterator;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.util.SystemOutLogger;
//import org.apache.poi.xssf.usermodel.XSSFCell;
//import org.apache.poi.xssf.usermodel.XSSFRow;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author Igor Verkhosh - September 2018
 *
 */

public class DataIO {
		public static String propertyFilePath = setTestDataFilePath();

	/**
	 * To Fetch the cell value from xls file
	 * @param objectName - Name of locator mentioned in the file
	 * @param fileName - Name of the file in which you need some data
	 * @return - list of related values correspond to the given locator
	 * @throws IOException
	 */
	public static ArrayList<String> getValueFromExcelFile(String objectName, String fileName) throws IOException{
		//String filePath = System.getProperty("user.dir")+"\\resources\\ObjectRepository\\"+fileName+".xls";
		String filePath = System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"ObjectRepository"+File.separator+fileName+".xls";

		FileInputStream fis = new FileInputStream(filePath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);
		ArrayList<String> elements = new ArrayList<String>();
		for(int i=0; i<= sheet.getLastRowNum(); i++){
			HSSFRow row = sheet.getRow(i);
			if(row.getCell(0).toString().equalsIgnoreCase(objectName)){
				elements.add(row.getCell(0).toString());
				elements.add(row.getCell(1).toString());
				elements.add(row.getCell(2).toString());
				break;
			}
		}
		workbook.close();
		return elements;
	}
	
	public static String setTestDataFilePath(){
//		return File.separator+"resources"+File.separator+"testData"+File.separator+getConfig("environment").toLowerCase().trim()+File.separator+"%22%.properties";
		return File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"testData"+File.separator+"%22%.properties";
		 
	}
	
	/**
     * readData From properties file
     * @param property
     * @return text
     */
    public static String getConfig(String property) {
        try {
            Properties prop = ResourceLoader.loadProperties(System.getProperty("user.dir") +File.separator+ "Config.properties");
            return prop.getProperty(property).trim();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
	
	/**
	 * To Overwrite existing value in properties file.
	 * @param property
	 * @param data
	 * @throws Exception
	 */
	public static void overwritePropertiesFile(String property, String data, String fileName) {
		try {
			FileInputStream in = new FileInputStream(System.getProperty("user.dir") + propertyFilePath.replaceAll("%22%", fileName));
		  	Properties props = new Properties();
		  	props.load(in);
		  	in.close();
		  	FileOutputStream out = new FileOutputStream(System.getProperty("user.dir") + propertyFilePath.replaceAll("%22%", fileName));
		  	props.setProperty(property, data);
		  	props.store(out, null);
		  	out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
      } 
    /**
     * readData From properties file
     * @param property
     * @return text
     */
    public static String get(String property, String fileName) {
        try {
        	if(fileName.trim().equalsIgnoreCase("Config")){
        		return getConfig(property);
        	}
        	Properties prop = ResourceLoader.loadProperties(System.getProperty("user.dir") + propertyFilePath.replaceAll("%22%", fileName));
            return prop.getProperty(property).trim();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static String updateDataInPropertiesFile(String key, String value,String filename){
		try {
			overwritePropertiesFile(key, value,filename);
		} catch (Exception e) {
			System.out.println(e);
		}
		return value;
	}
  
    public static void createTxtFileInDownloadFolder(String fileName){ 
    	try{  
    		// create new file	         
    		PrintWriter writer = new PrintWriter(System.getProperty("user.home")+File.separator+"Downloads" +File.separator + fileName + ".txt", "UTF-8");
    		writer.println("The first line");
    		writer.println("The second line");
    		writer.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}

    }


public static void UpdateExcelFile(String fileName, String SheetName, String Tabname) throws IOException{	
//		
//		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesToTest" + File.separator + fileName +".xlsx";
//		FileInputStream fileInputStream = new FileInputStream(new File(filePath));
//		String filePath2 = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested" + File.separator + fileName + 2 +".xlsx";
//        
//		File outputFile = new File(filePath2);
//		
//		if (!outputFile.exists()) {
//			outputFile.createNewFile();
//        }
//
//		//FileOutputStream fileOutputStream = new FileOutputStream(outputFile, true);
//		FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
//		
//		String s1= new String ("Tab is Visible");
//		//String s2= new String ("Tab is not Present");
//		
//		XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
//		XSSFSheet sheet = workbook.getSheet(SheetName);
//		for(int i=1; i<= sheet.getLastRowNum(); i++){
//			XSSFRow row = sheet.getRow(i);
//			String rowValue = row.getCell(0).getStringCellValue();
//			if(rowValue.equalsIgnoreCase(Tabname)){
//				//String s= new String ("Tab is Visible");
//				//System.out.println("Tab: " + Tabname + " Tab is Visible");
//				Cell cell = row.getCell(2);
//			    if(cell==null) {
//				    cell = row.createCell(2);
//					cell.setCellValue(s1);
//			    }
//				//workbook.write(fileOutputStream); 
//		 		//fileOutputStream.flush();
//				break;
//			}
////			else {
////				//String s= new String ("Tab is not Present");
////				//System.out.println("Tab: " + Tabname + " Tab is not Visible");
////				Cell cell = row.createCell(2);
////				cell.setCellValue(s2);
////		 		//fileOutputStream.flush();
////			}
//		}
//		fileInputStream.close();
//		workbook.write(fileOutputStream);  
//// 		fileOutputStream.flush();
////		fileOutputStream.close();
//		workbook.close();
//	}
//	
////	static void excelTocsvConvert(File inputFile, File outputFile) {
////		// For storing data into CSV files
////		StringBuffer data = new StringBuffer();
////		try {
////			FileOutputStream fos = new FileOutputStream(outputFile);
////
////			// Get the workbook object for XLSX file
////			XSSFWorkbook wBook = new XSSFWorkbook(new FileInputStream(inputFile));
////
////			// Get first sheet from the workbook
////			XSSFSheet sheet = wBook.getSheetAt(0);
////			Row row;
////			Cell cell;
////
////			// Iterate through each rows from first sheet
////			Iterator<Row> rowIterator = sheet.iterator();
////			while (rowIterator.hasNext()) {
////				row = rowIterator.next();
////
////				// For each row, iterate through each columns
////				Iterator<Cell> cellIterator = row.cellIterator();
////				while (cellIterator.hasNext()) {
////
////					cell = cellIterator.next();
////
////					switch (cell.getCellType()) {
////					case Cell.CELL_TYPE_BOOLEAN:
////						data.append(cell.getBooleanCellValue() + ",");
////
////						break;
////					case Cell.CELL_TYPE_NUMERIC:
////						data.append(cell.getNumericCellValue() + ",");
////
////						break;
////					case Cell.CELL_TYPE_STRING:
////						data.append(cell.getStringCellValue() + ",");
////						break;
////
////					case Cell.CELL_TYPE_BLANK:
////						data.append("" + ",");
////						break;
////					default:
////						data.append(cell + ",");
////
////					}
////				}
////				data.append('\n');
////			}
////
////			fos.write(data.toString().getBytes());
////			fos.close();
////
////		} catch (Exception ioe) {
////			ioe.printStackTrace();
////		}
////	}
//	static void writheToCSV(String fileName, String Tabname) {
//		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested" + File.separator + fileName +".csv";
//		//FileInputStream fileInputStream = new FileInputStream(new File(filePath));
//		// For storing data into CSV files
//		StringBuffer data = new StringBuffer();
//		try {
//
//			FileOutputStream fos = new FileOutputStream(filePath);
//			data.append(Tabname + "," + "Tab is Visible");
//			data.append('\n');
//			fos.write(data.toString().getBytes());
//			fos.close();
//
//		} catch (Exception ioe) {
//			ioe.printStackTrace();
//		}
}
   
}