package com.optum.actions;

import org.openqa.selenium.WebDriver;

import com.optum.utilities.DataIO;

//import com.workday.utils.DataIO;
public class HomePageActions extends BaseActions{
	
	WebDriver driver;
	
	public HomePageActions(WebDriver driver){
		super(driver);
		this.driver = driver;
	}

	public boolean verify_Home_Page_Loaded(){
		return isElementDisplayed("OptumLogo", "HomePage");
	}
	
	public boolean verify_Account_detail_Page(){
		return isElementDisplayed("Verify_Account_detail_page", "HomePage");
	}
	
	public void navigate_to_user_accounts(String AccountName){
		click("Accounts_tab","HomePage");
		click("AccountName","HomePage",AccountName);
	}
	
	public void navigate_to_User_Account(String CustomerName){
		hardWait(1);
		writeTextInto("GlobalSearch_txtbox", "HomePage", CustomerName);
		click("GlobalSearch_button", "HomePage");	
		hardWait(2);
		click("select_given_user_after_search_link", "HomePage", CustomerName);
		hardWait(2);
	}
	
public boolean verify_edit_button_is_available_on_accountdetailpage(String content){
	return getTextAndMatchString("Edit_button","AccountPage", content);
}

public void Click_on_All_Tab() {
	ClickonAllTabs("HomePage");	
}

/**
 *This Method is to verify home page for the User
 */
public boolean verify_User_Home_Page(String name){
	String locatorName;
	if (isElementPresent("AppLauncher_button", "HomePage")) {
		locatorName = "Logged_In_As_User_txt_LTtest";
	}
	else {
		locatorName = "Verify_User_Homepage";
	}
	return isElementDisplayed(locatorName, "HomePage", name);
}

public boolean lighteningEnabled() {
	if (isElementPresent("AppLauncher_button", "HomePage")) {
		return true;
	} else {
		return false;
	}
}

public void switchToClassic() {
	click("User_Image_LT", "HomePage");
	hardWait(2);
	click("Switch_to_Salesforce_Classic_link", "HomePage");
	hardWait(2);
	
}

public void switchToLightening() {
	hardWait(1);
	click("Switch_to_Lightning_link", "HomePage");
	hardWait(2);
}


}