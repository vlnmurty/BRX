package com.optum.utilities;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * @author Igor Verkhosh - September 2018
 *
 */
public class BasePage extends Locators {
	public WebDriver driver;

	public BasePage(WebDriver driver) {
		super(driver);
		this.driver = driver;

	}
	
	public void clickOn(String elementName, String fileName) {
		try {
			getElementWithoutWait(elementName, fileName).click();
		
    	} catch (Exception ex2) {
			logMessage("Element " + elementName + " could not be clicked! ");
			ex2.printStackTrace();
		}
	}

	public void click(String elementName, String fileName) {
		scrollDownTo(elementName,fileName);		
		try {
			getElement(elementName, fileName).click();
		
    	} catch (Exception ex2) {
			logMessage("Element " + elementName + " could not be clicked! ");
			ex2.printStackTrace();
		}
	}

	public void click(String elementName, String fileName, String textToReplace) {		
		try {
			String elemName = getElement(elementName, fileName, textToReplace).getText();
			if(elemName.equalsIgnoreCase(textToReplace)) {
				scrollDown (getElement(elementName, fileName, textToReplace));	
				getElement(elementName, fileName, textToReplace).click();
			}
			//getElement(elementName, fileName, textToReplace).click();
			
			} catch (Exception ex2) {
			logMessage("Element " + elementName + " could not be clicked! "+ ex2.getMessage());
			ex2.printStackTrace();
		}
	}
	
	protected void scrollDownTo(String elementName, String fileName){
		WebElement elementToScroll = getElement(elementName, fileName);
		scrollDown(elementToScroll);
	}
	
	protected void scrollDown(WebElement element) {
		((JavascriptExecutor) driver).executeScript(
				"arguments[0].scrollIntoView(true);", element);
	}

	public void writeTextInto(String elementName, String fileName,
			String textToReplace, String inputText) {
		
		try {
			getElement(elementName, fileName).clear();
			getElement(elementName, fileName, textToReplace)
					.sendKeys(inputText);
		
		} catch (Exception ex2) {
			ex2.printStackTrace();
		}
	}

	public void writeTextInto(String elementName, String fileName, String text) {
		getElement(elementName, fileName).clear();
		getElement(elementName, fileName).sendKeys(text);

	}
	
	public void writeTextIntoDateField(String elementName, String fileName, String text) {
		getElement(elementName, fileName).sendKeys(text);
	}
	
	public static String addRandomNumberToString(int numberDigits) {
		String randomNumber = Long.toString(Math.round(Math.random() * numberDigits));
		return randomNumber;
		
	}
//******************************************************************************************	

	public void hardWait(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void launchApplication(String URL) {
		driver.get(URL);
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public void logMessage(String message) {
		Reporter.log(message, true);
	}

	public String getCurrentURL() {
		return driver.getCurrentUrl();
	}
	
	protected int getElementSize (String elementName, String fileName) {
		List<WebElement> options = getElements(elementName, fileName);
		return options.size();
	}
	
	protected void verifyPageUrlContains(String pageUrlPart) {
		String currentUrl = getCurrentURL();
		logMessage("PASSED: Current Page url '" + currentUrl
				+ "' is expected!!!");
	}

	protected WebElement getElementByIndex(List<WebElement> elementlist, int index) {
		return elementlist.get(index);
	}

	protected WebElement getElementByExactText(List<WebElement> elementlist,
			String elementtext) {
		WebElement element = null;
		for (WebElement elem : elementlist) {
			if (elem.getText().equalsIgnoreCase(elementtext.trim())) {
				element = elem;
			}
		}
		// FIXME: handle if no element with the text is found in list No element
		// exception
		if (element == null) {
		}
		return element;
	}

	protected WebElement getElementByContainsText(List<WebElement> elementlist,
			String elementtext) {
		WebElement element = null;
		for (WebElement elem : elementlist) {
			if (elem.getText().contains(elementtext.trim())) {
				element = elem;
			}
		}
		// FIXME: handle if no element with the text is found in list
		if (element == null) {
		}
		return element;
	}

	public void switchwindow(String winHandleParent) {
		try {
			hardWait(3);
			for (String winHandleChild : driver.getWindowHandles()) {
				if (!winHandleChild.contains(winHandleParent)) {
					driver.switchTo().window(winHandleChild);
					hardWait(3);
				}
			}

		} catch (Exception e) {
			e.getMessage();
		}

	}

	protected void switchToFrame(WebElement element) {
		// switchToDefaultContent();
		wait.waitForElementToBeAppear(element);
		driver.switchTo().frame(element);
	}

	public void switchToFramebyIndex(int value) {
		hardWait(1);
		driver.switchTo().frame(value);
	}

	public void switchToDefaultContent() {
		hardWait(1);
		driver.switchTo().defaultContent();
		hardWait(1);
	}

	protected void executeJavascript(String script) {
		((JavascriptExecutor) driver).executeScript(script);
	}

	protected void javaScriptClick(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	protected void hover(WebElement element) {
		Actions hoverOver = new Actions(driver);
		hoverOver.moveToElement(element).build().perform();
	}

	protected void click_and_Select_and_Replace_ContentwithNewValue(
			String elementName, String fileName, String inputText) {
		Actions ClickSelectReplace = new Actions(driver);
		ClickSelectReplace.moveToElement(getElement(elementName, fileName))
				.clickAndHold().sendKeys(inputText).release().build().perform();
	}

	public void handleAlert() {
		try {
			hardWait(2);
			Alert alert = driver.switchTo().alert();
			String alertMessage= driver.switchTo().alert().getText();	
			System.out.println(alertMessage);
			logMessage("Alert handled..");
			alert.accept();		
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("Alert Not Present");
		}
	}
	
	public String verifyAlertPresentOrNot() {
		String alertText=null;
		try {
			alertText=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
			
		} catch (Exception e) {
			logMessage("Alert Not Present");
		}
		return alertText;
	}

	protected void hoverClick(WebElement element) {
		Actions hoverClick = new Actions(driver);
		hoverClick.moveToElement(element).click().build().perform();
	}

	private boolean isElementAHyperlink(WebElement element) {
		boolean flag = false;
		System.err.println("****** tag Name = " + element.getTagName());
		if (element.getTagName().equals("a")) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	protected void verifyElementIsHyperlinked(WebElement element) {
		Assert.assertTrue(isElementAHyperlink(element), "[Failed]: Element \'"
				+ element.getText() + "\' is not a hyperlink");
		logMessage("[Passed: Element \'" + element.getText()
				+ "\' is a hyperlink]");
	}

	protected void verifyElementIsNotHyperlinked(WebElement element) {
		Assert.assertTrue(!(isElementAHyperlink(element)),
				"[Failed]: Element \'" + element.getText()
						+ "\' is a hyperlink");
		logMessage("[Passed: Element \'" + element.getText()
				+ "\' is not a hyperlink]");
	}

	public String getText(String locator, String fileName) {
		String getText = null;
		getText = getElement(locator, fileName).getText();
		return getText;
	}
	
	public String getPrepopulatedText(String locator, String fileName) {
		String getText = null;
		getText = getElement(locator, fileName).getAttribute("value");
		return getText;
	}

	public String getvaluefromCheckbox(String locator, String fileName,
			String attribute) {
		String getText = null;
		getText = getElement(locator, fileName).getAttribute(attribute);
		if (getText.equals("Checked")) {
			getText = "Yes";
			return getText;
		} else {
			getText = "No";
			return getText;
		}
	}
	public boolean CheckingCheckboxforSurvey(String locator, String fileName){
		
		if (getElement(locator, fileName).getAttribute("title").equalsIgnoreCase("Checked")){
			return true;  
		}
	return false;
	}
	
	public boolean getAttributeAndMatchString(String locator, String fileName,
			String attribute,String textToVerify) {
		hardWait(3);
		if (getElement(locator, fileName).getAttribute(attribute).trim()
				.contains(textToVerify)) {
			return true;
		} else {
			return false;
		}	
	}


	public String getText(String locator, String fileName, String textToReplace) {
		String getText = null;
		getText = getElement(locator, fileName, textToReplace).getText();
		return getText;
	}

	public boolean getTextAndMatchString(String locator, String fileName,
			String textToReplace, String textToVerify) {
		hardWait(3);
		if (getElement(locator, fileName, textToReplace).getText().trim()
				.contains(textToVerify)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean getTextAndMatchString(String locator, String fileName, String textToVerify) {
		hardWait(1);
		System.out.println(getElement(locator, fileName).getText());
		if (getElement(locator, fileName).getText().trim().contains(textToVerify)) {
			return true;
		} else {
			return false;
		}
	}

	public void selectOptionByVisibleText(String dropdownElement,
			String fileName, String optionNeedToSelect) {
		Select dropdown = new Select(getElement(dropdownElement, fileName));
		dropdown.selectByVisibleText(optionNeedToSelect);
		hardWait(1);
	}

	public void selectOptionByIndex(String dropdownElement, String fileName, int index) {
		Select dropdown = new Select(getElement(dropdownElement, fileName));
		hardWait(1);
		dropdown.selectByIndex(index);
	}

	public void navigateToURL(String URL) {
		driver.navigate().to(URL);
	}

	public void gotobackpage() {
		hardWait(1);
		driver.navigate().back();
		hardWait(1);
	}

	public void closeCurrentBrowserWindow() {
		driver.close();
	}

	public void closeAllBrowserWindow() {
		driver.quit();
	}

	public boolean isElementPresent(String locator, String fileName) {
		boolean flag = false;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {
			if (getElementWithoutWait(locator, fileName) != null) {
				flag = true;
			}
		} catch (NoSuchElementException e) {
		} catch (Exception e1) {
		}
		driver.manage()
				.timeouts()
				.implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")),
						TimeUnit.SECONDS);
		return flag;
	}

	public boolean isElementPresent(String locator, String fileName,
			String textToReplace) {
		boolean flag = false;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {
			if (getElementWithoutWait(locator, fileName, textToReplace) != null) {
				flag = true;
			}
		} catch (NoSuchElementException e) {
		} catch (Exception e1) {
		}
		driver.manage()
				.timeouts()
				.implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")),
						TimeUnit.SECONDS);
		return flag;
	}

	public boolean getcheckboxvalue(String locator, String fileName,
			String replacement, String attribute) {
		String getText = null;
		getText = getElement(locator, fileName, replacement).getAttribute(
				attribute);
		System.out.println("getText=" + getText);
		if ((getText.equals("true"))||(getText.equals("Checked"))) {
			return true;
		} else {
			return false;
		}
	}
	
	//_______________________________________
	public void selectCheckBoxByValue(String locator, String fileName, String replacement) {
		WebElement checkBox = null;
		checkBox = getElement(locator, fileName, replacement);
				checkBox.click();
				hardWait(1);
	}
	//______________________________________

	public boolean isElementsPresent(String locator, String fileName) {
		boolean flag = false;
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			if (getElementsWithoutWait(locator, fileName).size() > 0) {
				flag = true;
			}
		} catch (NoSuchElementException e) {
			flag = false;
		}
		driver.manage()
				.timeouts()
				.implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")),
						TimeUnit.SECONDS);
		return flag;
	}
	
	
	public boolean isElementsPresent(String locator, String fileName, String textToReplace) {
		boolean flag = false;
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			if (getElementsWithoutWait(locator, fileName, textToReplace).size() > 0) {
				flag = true;
			}
		} catch (NoSuchElementException e) {
			flag = false;
		}
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")),
						TimeUnit.SECONDS);
		return flag;
	}

	public boolean isElementDisplayed(String locator, String fileName) {
		hardWait(1);
		try {
			if (getElement(locator, fileName).isDisplayed()) {
				return true;
			} else if (getElement(locator, fileName) == null) {
				return false;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isElementclickable(String locator, String fileName) {
		try {
			if (getElement(locator, fileName).getTagName() == "a") {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isElementReadonly(String locator, String fileName,String Replacement) {
		try {
			if ((getElement(locator, fileName,Replacement).getTagName() != "input"))
					 {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}
	
	public String getTagNameofElement(String locator, String fileName) {
		
			 String tagname = getElement(locator, fileName).getTagName();
			 return tagname;
			}
	
	public boolean isElementDisplayed(String locator, String fileName,
			String textToReplace) {
		hardWait(1);
		try {
			if (getElement(locator, fileName, textToReplace).isDisplayed()) {
				return true;
			} else if (getElement(locator, fileName, textToReplace) == null) {
				return false;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public void captureScreenshot(String screenshotName) {

		try {
			TakesScreenshot ts = (TakesScreenshot) driver;

			File source = ts.getScreenshotAs(OutputType.FILE);

			FileUtils.copyFile(source, new File("./Screenshots/"
					+ screenshotName + ".png"));

			System.out.println("Screenshot taken");
		} catch (Exception e) {

			System.out.println("Exception while taking screenshot "
					+ e.getMessage());
		}
	}

	public void rightClick(String elementName, String fileName) {
		Actions action = new Actions(driver);
		action.contextClick(getElement(elementName, fileName)).build()
				.perform();

	}

	public void actionClick(String elementName, String fileName) {
		Actions act = new Actions(driver);
		act.moveToElement(getElement(elementName, fileName)).click().build()
				.perform();
		hardWait(1);
	}

	public void doubleClick(String element, String fileName) {
		Actions action = new Actions(driver).doubleClick(getElement(element,
				fileName));
		action.build().perform();
	}

	public void pressEnterKey(String elementName, String fileName) {
		getElement(elementName, fileName).sendKeys(Keys.ENTER);

	}

	public void pressEnterKeyWithRobot() {
		Robot okRobot;
		try {
			okRobot = new Robot();
			hardWait(3);
			if (ExpectedConditions.alertIsPresent() != null) {
				System.out.println(driver.switchTo().alert().getText());
				driver.switchTo().alert().accept();
			}
			else {
				okRobot.keyPress(KeyEvent.VK_ENTER); // press Enter
				hardWait(1);
				
				okRobot.keyRelease(KeyEvent.VK_ENTER); // release Enter
				hardWait(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isElementNotEditable(String locator, String fileName) {
		try {
			System.out.println(getElement(locator, fileName).getTagName());
			if (!getElement(locator, fileName).getTagName().equalsIgnoreCase(
					"input")||getElement(locator, fileName).getTagName().equalsIgnoreCase(
							"textarea")) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public String getParentWindowHandle() {
		return driver.getWindowHandle();
	}

	public void switchToWindow(String windowHandle) {
		driver.switchTo().window(windowHandle);
		hardWait(2);
	}

	/**
	 * to get unique Id with added prefix
	 * 
	 * @param prefix
	 * @return
	 */
	public static String getToken(String prefix) {
		long current = System.currentTimeMillis();
		String token = prefix + current;
		return token;
	}

	/**
	 * To get future date by adding number of days in current date
	 * @param futureDateInDays
	 * @return
	 */
	public static String getDateWithWeekendExclusion(int futureDateInDays) {
		String currentDay = getDayForGivenDate(BasePage
				.getFutureDateByAddingGivenDays(futureDateInDays));
		if (currentDay.equalsIgnoreCase("Fri")
				|| currentDay.equalsIgnoreCase("Sat")
				|| currentDay.equalsIgnoreCase("Sun")) {
			futureDateInDays = futureDateInDays + 3;
		}
		return BasePage.getFutureDateByAddingGivenDays(futureDateInDays);
	}
	/**
	 * To get friday date by adding number of days in current date
	 * @param futureDateInDays
	 * @return
	 */
	public String getFridayDate(int futureDateInDays) {
		String currentDay = getDayForGivenDate(BasePage
				.getFutureDateByAddingGivenDays(futureDateInDays));
		
		switch (currentDay){
		case "Mon":
		futureDateInDays = futureDateInDays + 4;
		break;
		case "Tue":
	    futureDateInDays = futureDateInDays + 3;
		break;	
		case "Wed":
		futureDateInDays = futureDateInDays + 2;
	    break;
		case "Thu":
		futureDateInDays = futureDateInDays + 1;
		break;
		case "Fri":
		futureDateInDays = futureDateInDays + 7;
	    break;
		case "Sat":
		futureDateInDays = futureDateInDays + 6;
		break;
		case "Sun":
		futureDateInDays = futureDateInDays + 5;
		break;
		}
		return BasePage.getFutureDateByAddingGivenDays(futureDateInDays);
	}
	
	
 /**
	 * To get future date by adding number of days in current date
	 * @param futureDateInDays
	 * @return
	 */
	public static String getFutureDateByAddingGivenDays(int futureDateInDays) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, futureDateInDays);
		return sdf.format(cal.getTime()).trim();
	}
	
	public static String getPastDateBySubtractingGivenDays(int pastDateInDays) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, pastDateInDays);
		return sdf.format(cal.getTime()).trim();
	}
	
	public static String getFutureDateByAddingGivenDaysDayFirst(int futureDateInDays) {
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, futureDateInDays);
		return sdf.format(cal.getTime()).trim();
	}

	/**
	 * To get current Date Time
	 * @param futureDateInDays
	 * @return
	 */
	public static String getCurrentDateTime(String requiredFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(requiredFormat);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		return sdf.format(cal.getTime());
	}

	public void clickWhenClickable(WebElement element, int waitForSecons) {
		boolean flag = true;

		for (int i = 0; i <= waitForSecons; i++) {
			try {
				flag = true;
				element.click();
			} catch (Exception e) {
				System.out.println("not Clicked - " + i + e.getMessage());
				flag = false;
				hardWait(1);
			}
			if (flag) {
				break;
			}
		}
	}

	/**
	 * this methoed is to copy given text into clipboard
	 * @param textForCopy
	 */
	public void setClipboardData(String textForCopy) {
		StringSelection stringSelection = new StringSelection(textForCopy);
		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(stringSelection, null);
	}

	/**
	 * this method is to paste text (stored in clipboard) in focused text box
	 * and then perform enter on the same
	 */
	public void uploadFileWithSystemWindow() {
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 */
	public void SelectMultipleoptionfromMultiplepicklist(String dropdownElement,String fileName) {
		
			Select select = new Select(getElement(dropdownElement, fileName));
			Actions builder = new Actions(driver);
			builder.keyDown(Keys.CONTROL)
			.click(select.getOptions().get(0))
			.click(select.getOptions().get(1))
			.keyUp(Keys.CONTROL);
			builder.build().perform();		
	}
	

	/**
	 * This method is to fetch data from Ui and store fetched data into given property file
	 * @param element
	 * @param propertyKeyword
	 * @param fileName
	 */
	public void storeGivenTextInTempTestDataFile(String data, String propertyKeyword) {
		DataIO.overwritePropertiesFile(propertyKeyword, data, "TempTestData");
	}

	/**
	 * this method is get text from each element of list and verify given text
	 * is available or not
	 * @param textToVerify
	 */
	public boolean getTextFormElementsListAndMatchGivenString(
			List<WebElement> elementlist, String textToVerify) {
		for (WebElement elem : elementlist) {
			if (elem.getText().trim().equalsIgnoreCase(textToVerify.trim())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method is for verify the text from list.
	 */
	public boolean verifyTextInGivenList(String text, List<String> listOfText) {
		for (String value : listOfText) {
			if (value.trim().equalsIgnoreCase(text)) {
				return true;
			}
		}
		return false;
	}
	/**
	 * This method is to refresh the page.
	 */
	public void pagerefresh() {
		System.out.println("In page refresh");
		driver.navigate().refresh();
	}

	/**
	 * This method is for verify the values in given list of elements.
	 */
	public boolean verifyGivenValuesInDropdown(List<WebElement> elements,
			List<String> values) {
		ArrayList<String> subStatusDropDownValues = new ArrayList<String>();
		boolean flag = true;
		for (WebElement temp : elements) {
			subStatusDropDownValues.add(temp.getText().trim());
		}

		for (String subStatus : values) {
			if (verifyTextInGivenList(subStatus, subStatusDropDownValues) == false) {
				System.out.println(subStatus
						+ "  Value is not available in dropdown");
				flag = false;
			}
		}
		return flag;
	}

	public void scrollDownPage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,400)", "");
	}

	public static String getDayForGivenDate(String date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("M/d/yyyy");
		Date date1 = null;
		try {
			date1 = dateFormat.parse(date);
			dateFormat.applyPattern("EEE");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateFormat.format(date1);
	}
	public String get_SelectedOption(WebElement element) {
		Select select = new Select(element);
		WebElement selectedElement = select.getFirstSelectedOption();
		String selectedOption = selectedElement.getText();
		return selectedOption;
	}

	
	public WebElement getWhenClickable(By locator) {
        WebElement element;
        element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        return element;
    }
	/***********************************************************
	 ** Method to dismiss the Refresh Notification 
	 *********************************************************/
	public boolean isElementPresentUponLogin(String locator, String fileName) {
		boolean flag = false;
		hardWait(2);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {
			if (getElementWithoutWait(locator, fileName) != null) {
				flag = true;
			}
		} catch (NoSuchElementException e) {
		} catch (Exception e1) {
		}
		driver.manage()
				.timeouts()
				.implicitlyWait(Integer.parseInt(DataIO.getConfig("timeout")),
						TimeUnit.SECONDS);
		return flag;
	}
	
	public void mouseClickOnFooter() {
		hardWait(1);
		driver.findElement(By.cssSelector("#footer")).click();		
		
	}
	
	public String addUniqueIdentifire() {
        String accountNumber = Long.toString(Math.round(Math.random() * 899) + 100);
		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMddyyyy");
		String date = DATE_FORMAT.format(today);
		String uniqueID = date +"_" + accountNumber;
		return uniqueID;
	}

	public String randomDOB() {
		int yyyy = random(1930, 1999);
		int mm = random(1, 12);
		int dd = random(1, 28); // will set it later depending on year and month
		return Integer.toString(mm) + '/' + Integer.toString(dd) + '/' + Integer.toString(yyyy);
	}

	public static int random(int lowerBound, int upperBound) {
		return (lowerBound + (int) Math.round(Math.random() * (upperBound - lowerBound)));
	}
	
	// *********************************************************/
	 	public void ClickonAllTabs(String fileName){
			click("Click_on_Alltabs_Symbol", fileName);	
		}
	 	
		public void Open_Tabbed_Page(String tabName, String fileName, String allTabsLink) {
				ClickonAllTabs(fileName);
				click(allTabsLink, fileName);
		}

	//__________________________________________
		
//	    public static void highlightElement(WebElement element) {
//	        for (int i = 0; i <2; i++) {
//	            JavascriptExecutor js = (JavascriptExecutor) WebDriverFactory.getDriver();
//	            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: yellow; border: 2px solid yellow;");
//	            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
//	            }
//	        }	
//	    
/*
 * More generic Method to work with LookUp window	    
 */
		public void Select_Write_with_LookUp_Window(String FieldName, String SpreadsheetPageName,
				String LookUpContact, String LookUp_Icon, String LookUp_Search_Link) {
			hardWait(1);
			String winHandleParent = driver.getWindowHandle();
			switchwindow(winHandleParent);
			click(LookUp_Icon, SpreadsheetPageName);
			driver.switchTo().defaultContent();
				String title = driver.switchTo().frame(0).getTitle();
				System.out.println("Frame " + title);
				if (title !="") {
				String winHandlePopUpWindow = driver.getWindowHandle();
				switchwindow(winHandlePopUpWindow);
					driver.switchTo().defaultContent();
					String FrameSearchTitle = driver.switchTo().frame(0).getTitle();
					System.out.println("Frame " + FrameSearchTitle);		
					writeTextInto("LookUp_Search_Field", SpreadsheetPageName, LookUpContact);
					click("LookUp_Go_btn",SpreadsheetPageName);
					hardWait(2);
					driver.switchTo().defaultContent();
					String FrameResultsTitle = driver.switchTo().frame(1).getTitle();
					System.out.println("Frame " + FrameResultsTitle);		
					click(LookUp_Search_Link, SpreadsheetPageName, LookUpContact);
					hardWait(2);
				}	
			driver.switchTo().window(winHandleParent);

		}
//	    
////		/***********************************************************
////		 ** Method to click on all Links on the page
////		 *********************************************************/   
//		public List<WebElement> getAllSpecificElementsOnPage (String tagName) throws IOException {
//			ExcelLibrary objExcelFile = new ExcelLibrary();
//			String filePath = (System.getProperty("user.dir") + "\\src\\excelExportAndFileIO");
//			objExcelFile.readExcel(filePath, "MyExcelFile.xlsx", "ExcelSheetToTest");
//			waitForLoad(driver);	
//		    List<WebElement> allPageElements = driver.findElements(By.tagName(tagName));
//		    allPageElements.size();
//		    String[] allItems = new String [allPageElements.size()];
//		    int link = 0;
//			    for (WebElement all: allPageElements) {
//				    	allItems[link] = all.getText();
//				    	all.click();
//				    	System.out.println(	"\"" + "t" + "\"" + "View: " + allItems[link]);
//				    	driver.navigate().back();
//			    }
//			    return allPageElements;
//		}
//		
////		/***********************************************************
////		 ** Method to get list of all specific Elements on the page
////		 *********************************************************/   
//	public List<WebElement> getList_Of_All_Tabs_Visible_On_All_Tabs_Page(String xpathLocator, String FileName, String ProfileName) {
//
//		waitForLoad(driver);
//		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested"
//				+ File.separator + FileName + "_" + ProfileName + ".csv";
//		List<WebElement> allPageElements = driver.findElements(By.xpath(xpathLocator));
//		allPageElements.size();
//		String[] allItems = new String[allPageElements.size()];
//		System.out.println("Total Number of Visible Tabs on all Tabs Page: " + allPageElements.size());
//		StringBuffer data = new StringBuffer();
//		try {
//
//			FileOutputStream fos = new FileOutputStream(filePath);
//			data.append("Tab Name" + "," + "Tab Visibility" + '\n');
//			int link = 0;
//			for (WebElement all : allPageElements) {
//				allItems[link] = all.getText();
//				System.out.println("Tab Name: " + allItems[link]);
//				data.append(allItems[link] + "," + "Tab is Visible" + '\n');
//			}
//			// For storing data into CSV files
//			fos.write(data.toString().getBytes());
//			fos.close();
//		} catch (Exception ioe) {
//			ioe.printStackTrace();
//		}
//		return allPageElements;
//	}
//
//	@SuppressWarnings("resource")
//	public void Check_and_Click_On_All_Links_ON_Page(String ProfileName, String FileName, String SheetName) throws IOException {
//		String filetoReadPath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesToTest"
//				+ File.separator + FileName + ".xlsx";
//		File readFile = new File(filetoReadPath);
//		FileInputStream inputStream = new FileInputStream(readFile);
//		Workbook URLworkbook = new XSSFWorkbook(inputStream);
//		Sheet URLSheet = URLworkbook.getSheet(SheetName);
//		int rowCount = URLSheet.getLastRowNum() - URLSheet.getFirstRowNum();
//		for (int i = 0; i < rowCount + 1; i++) {
//			Row row = URLSheet.getRow(i);
//			String PageName = row.getCell(0).getStringCellValue();
//			String PageURL = row.getCell(1).getStringCellValue();
//			String Profile = row.getCell(2).getStringCellValue();
//			if (ProfileName.equalsIgnoreCase(Profile)) {
//				System.out.print(PageName + ", " + PageURL + ", " + Profile);
//				if (PageName.equalsIgnoreCase("UploadCoupons")) {
//					Set<String> tabs = driver.getWindowHandles();
//					Iterator<String> iterator = tabs.iterator();
//					if (tabs.size() > 1) {
//						while (iterator.hasNext()) {
//							String handle = iterator.next();
//							driver.switchTo().window(handle);
//						}
//					}
//					hardWait(1);
//				}
//				// if (PageName.equalsIgnoreCase("WOH_WeekViewCalendar") ||
//				// PageName.equalsIgnoreCase("WOH_MonthViewCalendar") ||
//				// PageName.equalsIgnoreCase("UploadCoupons"))
//				if (PageName.equalsIgnoreCase("UploadCoupons")) {
//					hardWait(1);
//				} else {
//					driver.get(PageURL);
//				}
//				hardWait(2);
//				String OpenedPageURL = driver.getCurrentUrl();
//				String OpenedPageTitle = driver.getTitle();
//				System.out.println("Page: " + OpenedPageURL + " Page Title: " + OpenedPageTitle);
//				hardWait(2);
//				String tagName = "a";
//				check_All_Links_On_Page(tagName, PageName, PageURL, FileName, ProfileName);
//				if (PageName.equalsIgnoreCase("UploadCoupons")) {
//					hardWait(2);
//				} else {
//					driver.navigate().back();
//				}
//				hardWait(2);
//			}
//			hardWait(1);
//			// System.out.println();
//		}
//		hardWait(1);
//		// return allPageLinks;
//	}
//	// /***********************************************************
//	// ** Method to click on all Page Links on the page
//	// *********************************************************/
//	public List<WebElement> check_All_Links_On_Page(String tagName, String Page, String URL, String FileName,
//			String ProfileName) throws IOException {
//		waitForLoad(driver);
//		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested"
//				+ File.separator + FileName + "_"+ Page +"_"+ ProfileName + ".csv";
//		// ExcelLibrary objExcelFile = new ExcelLibrary();
//		// objExcelFile.readExcel(filePath, "MyExcelFile.xlsx", "ExcelSheetToTest");
//
//		List<WebElement> allPageElements = driver.findElements(By.tagName(tagName));
//		int linksOnPage = allPageElements.size();
//		// int allItems = allPageElements.size();
//		System.out.println("Total Number of Visible Links on " + Page + " : " + linksOnPage);
//		StringBuffer data = new StringBuffer();
//		try {
//			FileOutputStream fos = new FileOutputStream(filePath);
//			data.append("Page Name" + "," + "Page Title" + "," + "Page URL" + "," + "Page Response" + '\n');
//			//// ********************************
//			for (int i = 0; i < linksOnPage; i++) {
//				String linkText = allPageElements.get(i).getAttribute("href");
//				System.out.println("Link: - " + linkText); // getText());
//				if (linkText != null) {
//					if (linkText.equalsIgnoreCase("mailto:support@workday.com")
//							|| linkText.equalsIgnoreCase("https://www.workday.com/partner_support.php") || linkText.equalsIgnoreCase("mailto:servicessupport@workday.com")
//							|| linkText.contains("javascript:")) {
//						continue;
//					}
//					String PageResponse = isLinkBroken(new URL(allPageElements.get(i).getAttribute("href")));
//					//System.out.println("URL: " + allPageElements.get(i).getAttribute("href") + " returned "+ isLinkBroken(new URL(allPageElements.get(i).getAttribute("href"))));				
//					System.out.println("URL: - " + allPageElements.get(i).getAttribute("href") + "- Page Responce: " + PageResponse);
//					String pageTitle = driver.getTitle();
//					data.append(Page + "," + pageTitle + "," + allPageElements.get(i).getAttribute("href") + "," + PageResponse + '\n');
//				}
//			}
//			// ________________________________
//			// For storing data into CSV files
//			fos.write(data.toString().getBytes());
//			fos.close();
//		} catch (Exception ioe) {
//			ioe.printStackTrace();
//		}
//		return allPageElements;
//	}
//	//**** added to check Brocken links
//	public static String isLinkBroken(URL url) throws Exception
//	 
//	{
// 
//		String response = "";
//		boolean redirect = false;
//		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
// 
//		try
// 
//		{
// 
//		    connection.connect();
// 
//		    response = connection.getResponseMessage();
//		    int status = connection.getResponseCode();
//		 	if (status != HttpURLConnection.HTTP_OK) {
//				if (status == HttpURLConnection.HTTP_MOVED_TEMP
//					|| status == HttpURLConnection.HTTP_MOVED_PERM
//						|| status == HttpURLConnection.HTTP_SEE_OTHER)
//				redirect = true;
//			}
//		 	if (redirect) {
//				// get redirect url from "location" header field
//				String newUrl = connection.getHeaderField("Location");
//				// get the cookie if need, for login
//				String cookies = connection.getHeaderField("Set-Cookie");
//				// open the new connection again
//				connection = (HttpURLConnection) new URL(newUrl).openConnection();
//				connection.setRequestProperty("Cookie", cookies);
//				connection.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
//				connection.addRequestProperty("User-Agent", "Mozilla");
//				connection.addRequestProperty("Referer", "google.com");
//
//				System.out.println("Redirect to URL : " + newUrl);
//				response = connection.getResponseMessage();
//			}
// 
//		    connection.disconnect();
// 
//		    return response;
// 
//		}
// 
//		catch(Exception exp)
// 
//		{
// 
//			return exp.getMessage();
// 
//		}  				
// 
//	}
	
	
}