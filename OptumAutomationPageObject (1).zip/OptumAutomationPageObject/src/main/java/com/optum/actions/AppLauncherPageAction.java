package com.optum.actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.optum.utilities.DataIO;

/**
 * @author Igor Verkhosh - October 2018
 */
public class AppLauncherPageAction extends BaseActions {
	
	public WebDriver driver;
	
	public AppLauncherPageAction(WebDriver driver){
		super(driver);
		this.driver = driver;
	}
	

	public void AppLauncher_Search_Select(String AppName) {
		hardWait(2);
		click("AppLauncher_button", "HomePage");
		writeTextInto("Search_Apps_Or_Items_LT_txtbox", "HomePage", AppName);
		clickOn("Pharmacist_Console_link_LT","HomePage");
		hardWait(2);
	}
}
