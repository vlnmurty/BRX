package com.optum.actions;

import org.openqa.selenium.WebDriver;
import com.optum.actions.BaseActions;

public class AllTabsPageActions extends BaseActions{
	
	WebDriver driver;

	public AllTabsPageActions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void Click_on_All_Tab(){
	ClickonAllTabs("HomePage");
	}
	
//	public void List_All_Visible_Tabs(){
//		getAllSpecificElementsOnPage("a");
//	}
	
//	public List<WebElement> getAllTabsElementsOnPage (String tagName) {
//		ExcelLibrary objExcelFile = new ExcelLibrary();
//		String filePath = (System.getProperty("user.dir") + "\\src\\excelExportAndFileIO");
//		try {
//			objExcelFile.readExcel(filePath, "MyExcelFile.xlsx", "ExcelSheetToTest");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		waitForLoad(driver);	
//	    List<WebElement> allPageElements = driver.findElements(By.tagName(tagName));
//	    allPageElements.size();
//	    String[] allItems = new String [allPageElements.size()];
//	    int link = 0;
//		    for (WebElement all: allPageElements) {
//			    	allItems[link] = all.getText();
//			    //	all.click();
//			    	System.out.println(	"\"" + "t" + "\"" + "View: " + allItems[link]);
//			    //	driver.navigate().back();
//		    }
//		    return allPageElements;
//	}

}
