package com.optum.actions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.optum.utilities.DataIO;

public class AssessmentPageActions extends BaseActions {
	
	public WebDriver driver;
	
	public AssessmentPageActions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void createNewAssessment(String Little_Interest,String FeelingDown, String Consent) {
		/*********** Education Section **********/
		click_NewAssesmentbutton(); //	click NewAssesment button
		select_AssessmentType("Assessment - Multiple Sclerosis Initial"); //select Assessment Type - Multiple Sclerosis Initial
		hardWait(2);
		System.out.println("Starting Assessment Education Section");
		select_GoalsTherapyReviewed("Yes"); //Goals of Therapy reviewed? - Yes
		select_HaveYouPreviouslyBeen("Never been on this medication before"); // Have you previously been on this medication? - Never been on
		enterPlannedStartDate(3); // First dose or planned start date?
		selectAnyOtherMedication("No");// Have you been on any other medication for this condition? - No
		enterDiagnosedDate(-30);// When were you diagnosed with MS? - past Date
		selectHowLongBeenTakingMedication("< 3 months");// How long have you been taking any medication for MS?   - <3 month
		selectPatientEducationProvided("Aid/Device Recommendation");// Select 	Patient Education Provided
		selectUnmanagedSideEffects("Fatigue");// Select In the past month, have you experienced any unmanaged side effects? - Abdominal Pain
		enter_Explanation_of_Side_Effects("Test Assessment");// Explanation of Side Effects - Test Assessment
		select_FrequencyOfPain("2 � Rarely");// How frequently does abdominal pain bother you? 2-Rarely
		select_As_compared_to_the_previous_month("Same");
		select_Next_Step_Based_on_the_information("Outreach to prescriber");
		select_Would_you_like_to_create_task("Yes", "Education");
		enter_Notes_for_Task("Education","Test Assessment");
		
		/*********** Support Section **********/
		System.out.println("Starting Assessment Support Section");
		select_Does_pt_agree_to_Briova_Live_consult("Yes - Agrees to consult");
		
        /*********** Assessment Section **********/
		System.out.println("Starting Assessment Assessment Section");
		select_Falls_ER_Hospitalization ("None"); // Falls, ER Visits, Hospitalizations - None
		select_Medication_Effectiveness_Relapse("No");// Medication Effectiveness/Relapse Information - No
		select_Unmanaged_MS_Symptoms("No Unmanaged MS Symptoms Currently");// Unmanaged MS Symptoms - No Unmaneged
		select_Based_on_the_information_shared("Outreach to prescriber"); // Based on the information shared concerning - Outreach to Prescriber
		select_Would_you_like_to_create_task("Yes", "Assessment"); // Would you like to create a task - Yes
		hardWait(1);
		enter_Notes_for_Task("Assessment","Test Assessment");
		
		/************Depression Screening *********/
		select_Little_interest_pleasure_doing_things(Little_Interest); // Little interest or pleasure in doing things? - 2
		select_Feeling_Down(FeelingDown); // Feeling down, depressed, or hopeless? - 1
		readPHQ_Score_Complete_Fields("Yes", "Outreach to prescriber");

		/************ Goals of Therapy *************/
		select_Goals_of_Therapy("Help control the activity of your disease");// Based on your consultation with the patient; please discuss - Help control the activity of your 
		enter_MoreDeatailsGoals_of_Theraphy();// Please provide more details regarding the primary goal of therapy - Test Assessment
        /*********** Wrap-Up Section **********/
		System.out.println("Starting Assessment Wrap-Up Section");
		select_RPh_consult_offered("Consult completed by RPh");// Was patient offered RPh consult? - Consult completed by RPh
		select_Is_Medication_Appropriate("Yes");// Is Medication Appropriate? - Yes
		select_Was_Plan_of_Care_Reviewed("Yes");// Was Plan of Care Reviewed? - Yes
		select_Did_patient_voice_understanding_Plan_of_Care("Yes");// Did the patient voice understanding of the Plan of Care? - Yes
		enter_Consult_Notes("");// Consult Notes -  Test Assessment
        /*********** Follow Up Section **********/
		System.out.println("Starting Assessment Follow Up Section");
		hardWait(1);
		select_Consent_To_Send_Email_Surveya(Consent);// Do We Have Your Consent To Send Email Surveys? - No
		click_Save_button(); // Save
		Assert.assertTrue(verify_Assessment_Created());
	}
	
	private void select_Consent_To_Send_Email_Surveya(String Consent) {
		selectOptionByVisibleText("Do We Have Your Consent To Send Email Surveys", "AssessmentPage", Consent);
		System.out.println("For Consent To Send Email Surveys selected: " + Consent);
	}

	private void enter_Consult_Notes(String ConsultNotes) {
		writeTextInto("Consult Notes", "AssessmentPage", "Test Assessment"); // Consult Notes - Test Assessment
		
	}

	private void select_Did_patient_voice_understanding_Plan_of_Care(String PatientUnderstanding) {
		selectOptionByVisibleText("Did the patient voice understanding of the Plan of Care", "AssessmentPage", PatientUnderstanding);
		
	}

	private void select_Was_Plan_of_Care_Reviewed(String CarePlanReviewed) {
		selectOptionByVisibleText("Was Plan of Care Reviewed", "AssessmentPage", CarePlanReviewed);
		
	}

	private void select_Is_Medication_Appropriate(String IsMedAppropriate) {
		selectOptionByVisibleText("Is Medication Appropriate", "AssessmentPage", IsMedAppropriate);
		
	}

	private void select_RPh_consult_offered(String RPhConsult) {
		selectOptionByVisibleText("Was patient offered RPh consult", "AssessmentPage", RPhConsult);
		hardWait(1);
	}

	private void enter_MoreDeatailsGoals_of_Theraphy() {
		writeTextInto("Please provide more details regarding the primary goal", "AssessmentPage", "Test Assessment"); // Details - Test Assessment
		
	}

	private void select_Goals_of_Therapy(String GoalsOfTherapy) {
		hardWait(1);
		selectOptionByVisibleText("Appropriate goal of therapy is to follow-up on", "AssessmentPage", GoalsOfTherapy);
		
	}

	public void readPHQ_Score_Complete_Fields(String TotalScore , String NextAppropriateStep) {
		hardWait(1);
		String PHQ2_Score = getText("PHQ-2_Score", "AssessmentPage");
		System.out.println("PHQ-2 Score = " + PHQ2_Score);
		if (Integer.parseInt(PHQ2_Score) >= 2 ) {
			selectOptionByVisibleText("If the total score is 2 or greater", "AssessmentPage", TotalScore); //Some of our members have an additional benefit from Optum - No
			hardWait(1);
			writeTextInto("Referral Comments", "AssessmentPage", "Test Assessment"); // Referral Comments - Test Assessment
			selectOptionByVisibleText("The patient has had a positive screening for depression", "AssessmentPage", NextAppropriateStep);  // Based on the information shared concerning - Outreach to Prescriber
			select_Would_you_like_to_create_task("Yes", "Depression"); // Would you like to create a task on the positive depression screening - Yes
			hardWait(1);
			enter_Notes_for_Task("Depression","Test Assessment"); // Notes for Task: - Test Assessment		
			hardWait(1);
		} else {
			writeTextInto("Referral Comments", "AssessmentPage", "Test Assessment"); // Referral Comments - Test Assessment
			hardWait(1);
		}		
	}

	public void select_Feeling_Down(String FeelingDown) {
		selectOptionByVisibleText("Feeling down, depressed, or hopeless", "AssessmentPage", FeelingDown);		
	}

	public void select_Little_interest_pleasure_doing_things(String LittleInterest) {
		selectOptionByVisibleText("Little interest or pleasure in doing things", "AssessmentPage", LittleInterest);		
	}

	public void select_Based_on_the_information_shared(String AppropriateNextStep) {
		selectOptionByVisibleText("Indicate what next step is most appropriate", "AssessmentPage", AppropriateNextStep);
		
	}

	public void select_Unmanaged_MS_Symptoms(String MS_Symptoms) {
		selectOptionByVisibleText("Unmanaged MS Symptoms", "AssessmentPage", MS_Symptoms);
		
	}

	public void select_Medication_Effectiveness_Relapse(String MedicationEffectiveness) {
		selectOptionByVisibleText("Have you had a relapse_exacerbation in the last month", "AssessmentPage", MedicationEffectiveness);		
	}

	public void select_Falls_ER_Hospitalization(String Falls_ER_Visits) {
		selectOptionByVisibleText("Have you had any falls_last_90_days_list", "AssessmentPage", Falls_ER_Visits);		
	}

	public void select_PST_Consult_Time(String ConsultTime) {
		selectOptionByVisibleText("PST Consult Time", "AssessmentPage", ConsultTime);		
	}

	public void select_Patient_Time_Zone(String PatienTimeZone) {
		selectOptionByVisibleText("Patient Time Zone", "AssessmentPage", PatienTimeZone);		
	}

	public void enterConsultDate(int consultDate) {
		String DiagnosedDay = getFutureDateByAddingGivenDays(consultDate);
		writeTextIntoDateField("ConsultDate", "AssessmentPage", DiagnosedDay );		
	}

	public void select_Does_pt_agree_to_Briova_Live_consult(String selectedAnswer) {
		hardWait(1);
		selectOptionByVisibleText("Does pt agree to Briova Live consult", "AssessmentPage", selectedAnswer);
		hardWait(1);
		if (selectedAnswer.contains("No")) {
		hardWait(1);
		}else if (selectedAnswer.contains("Yes")) {
			hardWait(1);
			writeTextInto("Email Address", "AssessmentPage", "igor.verkhosh@optum.com"); //enter_EmailAddress("igor.verkhosh@optum.com");
			hardWait(1);
			enterConsultDate(25);
	        hardWait(1);
	        select_Patient_Time_Zone("PST");
	        hardWait(1);
	        select_PST_Consult_Time("10:00 AM");
		}else if (selectedAnswer.contains("Other")) {
			hardWait(1);
			writeTextInto("Reason for Other", "AssessmentPage", DataIO.get("Reason_for_Other", "AssessmentTestData"));
		}
		hardWait(1);
	}

	public void enter_Notes_for_Task(String Section, String NotesForTask) {
		hardWait(1);
		if (Section.equalsIgnoreCase("Education")) {
			writeTextInto("Notes_for_Task_Education_txt", "AssessmentPage", NotesForTask);
		}else if (Section.equalsIgnoreCase("Assessment")) {
			writeTextInto("Notes_for_Task_Assessment_txt", "AssessmentPage", NotesForTask);
		}else if  (Section.equalsIgnoreCase("Depression")) {
			writeTextInto("Notes_for_Task_Depression_txt", "AssessmentPage", NotesForTask);
		}
		
	}

	public void select_Would_you_like_to_create_task(String createTask, String Section) {
		if (Section.equalsIgnoreCase("Education")) {
			selectOptionByVisibleText("Would you like to create a task Education", "AssessmentPage", createTask);
			hardWait(1);
		} else if (Section.equalsIgnoreCase("Assessment")) {
			selectOptionByVisibleText("Would you like to create a task Assessment", "AssessmentPage", createTask);
			hardWait(2);
		} else if (Section.equalsIgnoreCase("Depression")) {
			selectOptionByVisibleText("Would you like to create a task Depression", "AssessmentPage", createTask);
			if (createTask.equalsIgnoreCase("Yes")) {
			hardWait(1);
			}
		}
	}

	public void select_Next_Step_Based_on_the_information(String NextStep) {
		selectOptionByVisibleText("Based on the information shared concerning side effects", "AssessmentPage", NextStep);	
	}

	public void select_As_compared_to_the_previous_month(String CompareToPreviousMonth) {
		selectOptionByVisibleText("As compared to the previous month", "AssessmentPage", CompareToPreviousMonth);	
		
	}

	public void select_FrequencyOfPain(String FrequencyOfPain) {
		selectOptionByVisibleText("How frequently does fatigue bother you", "AssessmentPage", FrequencyOfPain);
		hardWait(1);
	}

	public void enter_Explanation_of_Side_Effects(String SideEffectsExplanation) {
		writeTextInto("Explanation of Side Effects", "AssessmentPage", SideEffectsExplanation );
		
	}

	public void selectUnmanagedSideEffects(String SideEffects) {
		selectOptionByVisibleText("Any unmanaged side effects", "AssessmentPage", SideEffects);			
	}

	public void selectPatientEducationProvided(String PatientEducation) {
		selectOptionByVisibleText("Patient Education Provided", "AssessmentPage", PatientEducation);	
	}

	public void selectHowLongBeenTakingMedication(String HowLong) {
		selectOptionByVisibleText ("How_long_have_you_been_dropbox", "AssessmentPage", HowLong);
	}

	public void enterDiagnosedDate(int daysAgo) {
		String DiagnosedDay = getFutureDateByAddingGivenDays(daysAgo);
		writeTextIntoDateField("When were you diagnosed with MS", "AssessmentPage", DiagnosedDay );		
	}

	public void selectAnyOtherMedication(String AnyOtherMeds) {
		selectOptionByVisibleText("Any other medication for this condition", "AssessmentPage", AnyOtherMeds);		
	}

	public void enterPlannedStartDate(int daysAdded) {
		//need to work with calendar not text
		String PlannedStartDay = getFutureDateByAddingGivenDays(daysAdded);
		writeTextIntoDateField("First dose or planned start date", "AssessmentPage", PlannedStartDay );
	}

	public void click_NewAssesmentbutton() {
		click("New_Assessment_btn", "AssessmentPage");		
	}
	
	public void select_AssessmentType(String AssessmentType) {
		selectOptionByVisibleText("AssessmentType_dropdown", "AssessmentPage", AssessmentType);		
	}
	
	public void select_GoalsTherapyReviewed(String Reviewed) {
		selectOptionByVisibleText("GoalsTherapyReviewed_dropdown", "AssessmentPage", Reviewed);		
	}
	
	public void select_HaveYouPreviouslyBeen(String HaveYouBeen) {
		selectOptionByVisibleText("Have_you_previously_been_medication_dropdown", "AssessmentPage", HaveYouBeen);		
	}
	public void click_Save_button() {
		click("Save_button", "AssessmentPage");
		hardWait(2);
	}
	public boolean verify_Assessment_Created() {
		hardWait(2);
		String Assessment_Name = getText("Assessment_Name_text", "AssessmentPage");
		if (Assessment_Name !="") {
		System.out.println("Assessment Name " + Assessment_Name +" created");
		hardWait(1);
		return true;
		} else {
			hardWait(1);
			return false;
			}
	}
	
	public void openAssessmentPatientAccount() {
		click("PatientAccountName_link", "AssessmentPage");
		hardWait(2);
		
	}

}
