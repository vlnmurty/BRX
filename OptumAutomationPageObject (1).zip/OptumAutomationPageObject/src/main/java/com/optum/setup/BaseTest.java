package com.optum.setup;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import com.optum.utilities.DataIO;

/**
 * @Igor Verkhosh - October 2018
 *
 */
public abstract class BaseTest {

	public static TestSessionInitiator tsi;

	@BeforeSuite
	public void tearUp(){
		tsi = new TestSessionInitiator();
		tsi.baseAction.launchApplication(DataIO.get("salesForceURL", "Config"));
		tsi.loginPage.PERFORM_LOGIN_IN_OPTUM(DataIO.get("admin_email", "Config"), DataIO.get("admin_password", "Config"));
		String Lightening = DataIO.get("lighteningEnabled", "Config");

		if ( Lightening.equalsIgnoreCase("Yes") != true) {
			if (tsi.homepage.lighteningEnabled() != true) {
				Assert.assertTrue(tsi.homepage.verify_Home_Page_Loaded());
			} else {
				tsi.homepage.switchToClassic();
				Assert.assertTrue(tsi.homepage.verify_Home_Page_Loaded());
			}
		}else {
			if (tsi.homepage.lighteningEnabled() != true) {
				tsi.homepage.switchToLightening();
				Assert.assertTrue(tsi.homepage.lighteningEnabled());
			} else {
				Assert.assertTrue(tsi.homepage.lighteningEnabled());
			}
		}
	}

	@BeforeTest
	public void setApplicationLaunchingURL(){
		tsi.baseAction.getCurrentURLAndSaveInDataFile("ApplicationLaunchingURL", "TempTestData");
	}

	@AfterSuite
	public void tearDown(){
		tsi.close();
	}
	
}
	
