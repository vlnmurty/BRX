package com.optum.testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.optum.setup.BaseTest;

public class CreateNewPatient_Prescription extends BaseTest{
		
		@AfterClass
		public void RefreshSession(){
			tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
		}
		
		@BeforeTest
		public void getStartTime() {
			tsi.baseAction.getStartTime();
		}
		
		@AfterTest
		public void getEndTime() {
			tsi.baseAction.getEndTime();
		}
			    
		    @Test(priority=1, enabled=true, invocationCount=1)   
		    /******************************************************
		     * Login as user into Salesforce User Classic
		     ******************************************************/	   
		 public void create_New_Person_Account() {   
		    tsi.accountsPageLT.createNewPersonAccount_LT();
		    }  
		 
		    @Test (dependsOnMethods= "create_New_Person_Account")//(priority = 2, enabled = true, invocationCount = 1)
		 public void add_New_Prescription() {   
		    tsi.prescriptionPageLT.addNewPrescription_LT();
		 }
		    @Test (dependsOnMethods= "add_New_Prescription")//(priority = 2, enabled = true, invocationCount = 1)
		    public void add_New_Adverse_Event() {
		    	tsi.adverseEventPageLT.addNewAdverseEvent_LT();
		    }
		    
//		    tsi.assessmentPage.createNewAssessment("1","1","Yes");	    
////		    // Logout as this User
////		    tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempData", this.getClass().getSimpleName());

}