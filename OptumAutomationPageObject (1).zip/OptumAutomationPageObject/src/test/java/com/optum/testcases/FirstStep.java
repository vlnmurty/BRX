package com.optum.testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.optum.setup.BaseTest;

public class FirstStep extends BaseTest{
	
	@BeforeClass
	public void getStartTime() {
		tsi.baseAction.getStartTime();
	}
	
    @Test(priority=1, enabled=true, invocationCount=1)  
	public void createNewPersonAccount_LT(){
		
	tsi.accountsPageLT.AppLauncher_Search_Select("PCC/Pharmacist Console");	
	tsi.accountsPageLT.goToNewPersonPAge();
	tsi.accountsPageLT.type_FirstName();
	tsi.accountsPageLT.type_LastName();
	tsi.accountsPageLT.selectSourceData();
	tsi.accountsPageLT.type_DOB();
	tsi.accountsPageLT.select_Gender();
	tsi.accountsPageLT.type_Phone_Num();
	tsi.accountsPageLT.type_Mobile_Num();
	tsi.accountsPageLT.type_Email();
	tsi.accountsPageLT.click_Save_button();
	tsi.accountsPageLT.verify_User_Created();
	}
	
    @Test (dependsOnMethods= "createNewPersonAccount_LT")//(priority = 2, enabled = true, invocationCount = 1)
 public void add_New_Prescription() {   
    tsi.prescriptionPageLT.addNewPrescription_LT();
 }
    @Test (dependsOnMethods= "add_New_Prescription")//(priority = 2, enabled = true, invocationCount = 1)
    public void add_New_Adverse_Event() {
    	tsi.adverseEventPageLT.addNewAdverseEvent_LT();
    }
	
	@AfterClass
	public void RefreshSession(){
		tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
		tsi.baseAction.getEndTime();
	}
}


