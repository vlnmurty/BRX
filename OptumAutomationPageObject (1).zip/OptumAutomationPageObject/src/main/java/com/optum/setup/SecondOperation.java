package com.optum.setup;
public class SecondOperation implements Runnable
{
	public SecondOperation(){
		  CustomizedReporting.createCustomTestngReport();

	}
  public void run(){
  CustomizedReporting.createCustomTestngReport();
 }
} 