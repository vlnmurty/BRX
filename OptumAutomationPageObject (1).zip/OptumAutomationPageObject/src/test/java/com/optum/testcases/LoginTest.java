package com.optum.testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.optum.actions.AccountsPageActionsLT;
import com.optum.setup.BaseTest;

public class LoginTest extends BaseTest{
		
		@AfterClass
		public void RefreshSession(){
			tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
		}
		@BeforeTest
		public void getStartTime() {
			tsi.baseAction.getStartTime();
		}
		
		@AfterTest
		public void getEndTime() {
			tsi.baseAction.getEndTime();
		}
		
//	    @Test(priority=1, enabled=true, invocationCount=1)   
//	    /******************************************************
//	     * Login as user into Salesforce User Classic
//	     ******************************************************/	
//		public void login_To_Salesforce_As_ClassicUser(){
//			
////		    tsi.baseAction.search_for_User("Classic_User");	
////		    tsi.baseAction.login_As_User("Classic_User");
//		    tsi.baseAction.click_on_Tab("Home_Tab");
////		    Assert.assertTrue(tsi.homepage.verify_User_Home_Page("User Classic"));
//	    }
		    
		    @Test(priority=1, enabled=true, invocationCount=1)   
		    /******************************************************
		     * Login as user into Salesforce User Classic
		     ******************************************************/	   
		 public void create_New_Person_Account() {   	
		    tsi.accountsPageLT.AppLauncher_Search_Select("PCC/Pharmacist Console");
		    tsi.accountsPageLT.goToNewPersonPAge();
		    tsi.accountsPageLT.hardWait(2);
		    tsi.accountsPageLT.type_FirstName();
		    tsi.accountsPageLT.type_LastName();
		    tsi.accountsPageLT.selectSourceData(); // ScriptMed only at this time/if IRIS selected enter IRIS Account Number
		    tsi.accountsPageLT.type_DOB ();
		    tsi.accountsPageLT.select_Gender();
		    tsi.accountsPageLT.type_Phone_Num ();
		    tsi.accountsPageLT.type_Mobile_Num ();
		    tsi.accountsPageLT.type_Email ();
		    tsi.accountsPageLT.click_Save_button();
		    tsi.accountsPageLT.verify_User_Created();
		    tsi.accountsPageLT.hardWait(2);		
			}
		    
//		    tsi.prescriptionPageLT.addNewPrescription_LT();
		    
//		    tsi.assessmentPage.createNewAssessment("1","1","Yes");	    
////		    // Logout as this User
////		    tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempData", this.getClass().getSimpleName());
//    }
		    
//	    @Test(priority=3, enabled=false, invocationCount=1)   
//	    /******************************************************
//	     * Login as user into Salesforce AccountManager
//	     ******************************************************/
//		public void login_To_Salesforce_As_User(){
////			
////			    tsi.baseAction.search_for_User("AccountManager");	
//////			    tsi.baseAction.login_As_User("AccountManager");
////			    tsi.baseAction.click_on_Tab("Home_Tab");
//////			    Assert.assertTrue(tsi.homepage.verify_User_Home_Page("Account Manager"));
////			    tsi.baseAction.click_on_Tab("Accounts_tab");
//	    }
	    
}