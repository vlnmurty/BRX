package com.optum.actions;
	
	import java.util.List;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import com.optum.utilities.DataIO;

	/**
	 * @author Igor Verkhosh - September 2018
	 */
	public class PrescriptionPageActionLT extends BaseActions{

		public WebDriver driver;
		
		public PrescriptionPageActionLT(WebDriver driver){
			super(driver);
			this.driver = driver;
		}

		public void addNewPrescription_LT() {
			clickNewPrescription();
			selectPrescriptionStatus("Scheduled");
			selectSourceRx(); // this include pharmacy code and typeRx_Referal_Number("Rx number or Scriptmed Referral number");
			selectDrugTherapy();
			selectPrescriberContact("PrescriberContact");
			selectMedication_Strenght(); //ENBREL SURECLICK 50MG/ML 9 / XELJANZ XR TAB 11MG / VERZENIO TAB 50MG / GAMASTAN S/D INJ 2ML / HCG INJ 10000U
			writeTextIntoSIG();
			writeTextIntoQuantity();
			writeTextIntoRefils();
			selectTreatmentExperienceStatus();
			click_Save_button();
			hardWait(3);
			Assert.assertTrue(verify_Prescription_Created_LT());
			hardWait(2);

		}
		
		public void addNewPrescriptionToExistingPatient_LT() {
			searchForPatient();
			clickNewPrescription();
			selectPrescriptionStatus("Scheduled");
			selectSourceRx(); // this include pharmacy code and typeRx_Referal_Number("Rx number or Scriptmed Referral number");
			selectDrugTherapy();
			selectPrescriberContact("PrescriberContact");
			selectMedication_Strenght(); //ENBREL SURECLICK 50MG/ML 9 / XELJANZ XR TAB 11MG / VERZENIO TAB 50MG / GAMASTAN S/D INJ 2ML / HCG INJ 10000U
			writeTextIntoSIG();
			writeTextIntoQuantity();
			writeTextIntoRefils();
			selectTreatmentExperienceStatus();
			click_Save_button();
			Assert.assertTrue(verify_Prescription_Created());
		}
		public void searchForPatient() {
			String SearchString = DataIO.get("PatientAccountName", "TempTestData");
			search_for_GlobalSearch(SearchString);
			hardWait(2);
			click("accountName_lnk","AccountsPage", SearchString);
		}

		public void clickNewPrescription() {
			hardWait(1);
//			click("NewPrescribtion_button", "AccountsPage");
			driver.findElement(By.xpath("//div[@class = 'slds-no-flex']//following-sibling::*//a[@title ='New']")).click();
			hardWait(2);
		}
		
		public void selectPrescriptionStatus(String PrescriptionStatus) {
			driver.findElement(By.xpath("(//a[@class='select'])[1]")).click(); // Prescription Status
			driver.findElement(By.xpath("//a[@title='Scheduled']")).click(); // Prescription Status selection
			hardWait(1);
//			selectOptionByVisibleText("PrescriptionStatus_dropbox", "PrescriptionPage", PrescriptionStatus);
		}

		public void selectSourceRx() {
			String SourceRx = null;
			String RxNumber = null;
			String ScriptMedReferalNum = null;
			ScriptMedReferalNum = addRandomNumberToString(89999999);
			RxNumber = addRandomNumberToString(89999999);
			
			int SourceDataSelection = 1; //(int) Math.round(Math.random());
			hardWait(1);
			if (SourceDataSelection != 1) {
				SourceRx = "IRIS";
				System.out.println("SourceRx: " + SourceRx + " Rx Number: " + RxNumber);
				driver.findElement(By.xpath("(//a[@class='select'])[2]")).click();
				hardWait(1);
				driver.findElement(By.xpath("//a[@title='IRIS']")).click();
				driver.findElement(By.xpath("(//label[contains(.,'Rx Number')]//following-sibling::input")).sendKeys(RxNumber);
				hardWait(1);
//				selectOptionByVisibleText("SourceRx_dropbox", "PrescriptionPage", SourceRx);
//				writeTextInto("RxNumber_txtbox", "PrescriptionPage", RxNumber);
			}else {
				SourceRx = "ScriptMed";
				System.out.println("SourceRx: " + SourceRx + " ScriptMed Referal Number: " + ScriptMedReferalNum);
				driver.findElement(By.xpath("(//a[@class='select'])[2]")).click();
				hardWait(1);
				driver.findElement(By.xpath("//a[@title='ScriptMed']")).click();
				hardWait(1);
				selectPharmacyCode();
				driver.findElement(By.xpath("(//input[@type='text'])[26]")).sendKeys(RxNumber);
				hardWait(1);
//				selectOptionByVisibleText("SourceRx_dropbox", "PrescriptionPage", SourceRx);
//				hardWait(1);
//				selectPharmacyCode();	
//				writeTextInto("RxNumber_txtbox", "PrescriptionPage", RxNumber);
//				writeTextInto("ScriptMedReferalNumber_txt", "PrescriptionPage", ScriptMedReferalNum);
			}
				driver.findElement(By.xpath("//label[contains(.,'ScriptMed Referral Number')]//following-sibling::input")).sendKeys(ScriptMedReferalNum);
				hardWait(1);
		}

		public void selectPrescriber(String Prescriber) {
//			String PrescriberName = DataIO.get(Prescriber, "PrescriptionTestData");
//			driver.findElement(By.xpath("//input[@placeholder='Search Contacts...']")).sendKeys(PrescriberName);
//			driver.findElement(By.xpath("//div[@title='"+PrescriberName+"']")).click();
//			writeTextInto("Prescriber_Info_txt", "PrescriptionPage", DataIO.get(Prescriber, "PrescriptionTestData"));
			hardWait(1);
//			String winHandleParent = driver.getWindowHandle();
//			click("Prescriber_Contact_lookup", "PrescriptionPage");
//			hardWait(1);
//			switchwindow(winHandleParent);
//			hardWait(1);
//			click("Lookup_Go_btn", "PrescriptionPage", Prescriber);
//			switchToFramebyIndex(1);
//			click("Prescriber_Contact_Link", "PrescriptionPage", Prescriber);
//			hardWait(1);
//			driver.switchTo().window(winHandleParent);

		}
		
		public void selectPrescriberContact(String Prescriber) {
			String PrescriberName = DataIO.get(Prescriber, "PrescriptionTestData");
			driver.findElement(By.xpath("//input[@placeholder='Search Contacts...']")).sendKeys(PrescriberName);
			driver.findElement(By.xpath("//div[@title='"+PrescriberName+"']")).click();			
//			writeTextInto("Prescriber_Contact_txt", "PrescriptionPage", DataIO.get(Prescriber, "PrescriptionTestData"));
			hardWait(1);
		}
		
		// Selecting Pharmacy Code based on the drop-down box size - need clear identification of the drop-box
		public void selectPharmacyCode() {
			hardWait(2);
			long PharmacyCodeIndex = addRandomNumber(26);
				PharmacyCodeIndex = PharmacyCodeIndex+38;
				driver.findElement(By.xpath("(//a[@class='select'])[3]")).click(); //Pharmacy Code dropdown
				driver.findElement(By.xpath("(//a[@tabindex='0'])[" + PharmacyCodeIndex + "]")).click(); // Pharmacy  Code
				hardWait(1);
				//selectOptionByIndex("PharmacyCode_dropbox", "PrescriptionPage", (int) PharmacyCodeIndex);
		}
		
		private void selectDrugTherapy() {
			String DrugTherapy = DataIO.get("DrugTherapy", "PrescriptionTestData");
			driver.findElement(By.xpath("//input[@title='Search Drug Therapies']")).sendKeys(DrugTherapy);
			driver.findElement(By.xpath("//div[@title='"+ DrugTherapy + "']")).click();	 			//div[@title='BRENDA BARNES - Humira']
			hardWait(1);
//			writeTextInto("DrugTherapy_txt", "PrescriptionPage", DataIO.get("DrugTherapy", "PrescriptionTestData"));
			
		}

		public void selectMedication_Strenght() {
			String Medication_Strenght = getMedicationStrenght();
			String trimmedText = Medication_Strenght.split(" ")[0];
			driver.findElement(By.xpath("//input[@placeholder='Search Drugs...']")).sendKeys(Medication_Strenght);
			driver.findElement(By.xpath("//mark[@class='data-match'][contains(.,'" + trimmedText + "')]")).click();	
			hardWait(1);
//			writeTextInto("Med_and_Strenght_txt", "PrescriptionPage",getMedicationStrenght());
		}

		public void writeTextIntoSIG() { //"Take one tabled by mouse every day"
			driver.findElement(By.xpath("//label[contains(.,'SIG')]//following-sibling::textarea")).sendKeys(DataIO.get("SIG_text", "PrescriptionTestData"));
//			writeTextInto("SIG_txtbox", "PrescriptionPage", DataIO.get("SIG_text", "PrescriptionTestData"));
		}
		
		public void writeTextIntoQuantity() { //60
			driver.findElement(By.xpath("//label[contains(.,'Quantity')]//following-sibling::input")).sendKeys(DataIO.get("Quantity_text", "PrescriptionTestData"));
//			writeTextInto("Quantity_txtbox", "PrescriptionPage", DataIO.get("Quantity_text", "PrescriptionTestData"));
		}
		public void writeTextIntoRefils() { //2
			driver.findElement(By.xpath("//label[contains(.,'Refills')]//following-sibling::input")).sendKeys(DataIO.get("Refils_text", "PrescriptionTestData"));
//			writeTextInto("Refils_txtbox", "PrescriptionPage", DataIO.get("Refils_text", "PrescriptionTestData"));
		}
		
		public void selectTreatmentExperienceStatus() {
			
		}
		
		public void click_Save_button() {
			driver.findElement(By.xpath("//button[contains(.,'Save & New')]//following-sibling::button")).click();		
//			click("Save_button", "AccountsPage");
		}
		
	/* Verify Prescription Created / Added to a person */
	public boolean verify_Prescription_Created_LT() {
		hardWait(1);
		boolean Status = false;
		List<WebElement> createdNumbers = driver.findElements(By.xpath("(//div[contains(.,'Prescription')])//following-sibling::h1/span"));
		for (WebElement created : createdNumbers) {
			String Prescription_Number = created.getText();
//			String Prescription_Number = getText("Prescription_Number_LT", "PrescriptionPage");
			if (Prescription_Number.equalsIgnoreCase("New Prescription")) {
				System.out.println("Prescription is not created");
				Reporter.log("Prescription is not created");
				Status =  false;
			}else if (Prescription_Number.equalsIgnoreCase("")) {
				hardWait(1);
			}
			else {
				System.out.println("Prescription " + Prescription_Number + " created");
				Reporter.log("Prescription " + Prescription_Number + " created");
				Status = true;
			}
		}
		return Status;
	}
		/* Verify Prescription Created / Added to a person */
		public boolean verify_Prescription_Created() {
			hardWait(1);
			String Prescription_Number = getText("Prescription_Number", "PrescriptionPage");
			if (Prescription_Number.equalsIgnoreCase("New Prescription")) {
				System.out.println("Prescription is not created");
				Reporter.log("Prescription is not created");
				return false;
			} else {
				System.out.println("Prescription " + Prescription_Number + " created");
				Reporter.log("Prescription " + Prescription_Number + " created");
				return true;
			}
		}

		/* To select getMedicationStrenght from data file */
		public String getMedicationStrenght() {
			int Med_Strenght = random(1,4);
			String Medication_Strenght = null;
			Medication_Strenght = DataIO.get("Medication_Strenght_" + Med_Strenght, "PrescriptionTestData");
			return Medication_Strenght;
		}
	
}
