package com.optum.actions;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.optum.utilities.DataIO;

/**
 * @author Igor Verkhosh - October 2018
 */
public class AccountsPageActionsLT extends BaseActions{

	public WebDriver driver;
	
	public AccountsPageActionsLT(WebDriver driver){
		super(driver);
		this.driver = driver;
	}
	
	public void createNewPersonAccount_LT() {
		
		AppLauncher_Search_Select("PCC/Pharmacist Console");
		goToNewPersonPAge();
		type_FirstName();
	    type_LastName();
	    selectSourceData(); // ScriptMed only at this time/if IRIS selected enter IRIS Account Number
		type_DOB ();
		select_Gender();
		type_Phone_Num ();
		type_Mobile_Num ();
		type_Email ();
	    click_Save_button();
	    verify_User_Created();
	}	
	
	public void AppLauncher_Search_Select(String AppName) {
		hardWait(2);
		click("AppLauncher_button", "HomePage");
		writeTextInto("Search_Apps_Or_Items_LT_txtbox", "HomePage", AppName);
		clickOn("Pharmacist_Console_link_LT","HomePage");
		hardWait(2);
	}
	public void goToNewPersonPAge(){
		pageCleanUp();
		clickOn("Account_Tab_LT", "AccountsPage");
		hardWait(2);
		click("New_button_LT", "AccountsPage");
		hardWait(2);
		click("PersonAccountRecordType_LT_radio", "AccountsPage");
		click("Next_LT_button", "AccountsPage");
		hardWait(2);
	}

	public void type_FirstName() {
		String FirstName = DataIO.get("FirstName", "AccountsTestData")+(addRandomNumberToString(9999));
		DataIO.updateDataInPropertiesFile("PersonFirstName", FirstName, "TempTestData");
		writeTextInto("FirstName_LT_txtbox", "AccountsPage", FirstName);
		
	}
	
	public void type_LastName() {
		String LastName = DataIO.get("LastName", "AccountsTestData") + (addRandomNumberToString(99999)); 
		DataIO.updateDataInPropertiesFile("PersonLastName", LastName, "TempTestData");
		writeTextInto("LastName_LT_txtbox", "AccountsPage", LastName);
		
	}
	
	public void selectSourceData() {
		
		String SourceData = null;
		String CustomerNumber = null;
		String ScriptMedPatientID = "SM" + addRandomNumberToString(89999999);;
		int SourceDataSelection = 2; //ScriptMed only at this time// (int) Math.round(Math.random());

		if (SourceDataSelection != 1) {
			SourceData = "IRIS";
			CustomerNumber = addRandomNumberToString(89999999);
			System.out.println("SourceData: " + SourceData);
			System.out.println("Customer Number: " + CustomerNumber);
			clickOn("SourceData_LT_dropdown", "AccountsPage");
			clickOn("Iris_Dropdown_LT_selection", "AccountsPage");
			writeTextInto("IRIS_Acc_Num_LT_txtbox", "AccountsPage", CustomerNumber);
		}else {
			SourceData = "ScriptMed";

			System.out.println("SourceData: " + SourceData);
			System.out.println("ScriptMed Patient ID: " + ScriptMedPatientID);
			click("SourceData_LT_dropdown", "AccountsPage");
			click("ScriptMed_Dropdown_LT_selection", "AccountsPage");	
		}		
		writeTextInto("ScriptMedPatientID_LT_txt", "AccountsPage", ScriptMedPatientID);
	}
	
	public void type_DOB() {
		String randomDOB = randomDOB();
		writeTextInto("DateOfBirth_LT_txt", "AccountsPage", randomDOB);
		DataIO.updateDataInPropertiesFile("PersonDOB", randomDOB, "TempTestData");
	}

	public void select_Gender() {
		int GenderSelection = (int) Math.round(Math.random());
		String Gender;
		if (GenderSelection != 1) {
			Gender = "Male";
		} else {Gender = "Female";}
		
		clickOn("Gender_LT_dropdown", "AccountsPage");
		click("Gender_Dropdown_LT_selction", "AccountsPage", Gender);
	}

	public void type_Phone_Num() {
		String AreaCode = addRandomNumberToString(899);
		String PhoneNumber = addRandomNumberToString(8999999);
		writeTextInto("PhoneNumber_LT_txt", "AccountsPage", AreaCode+PhoneNumber);
		hardWait(1);
	}
	
	public void type_Mobile_Num() {
		String AreaCode = addRandomNumberToString(899)+100;
		String PhoneNumber = addRandomNumberToString(8999999);
		writeTextInto("Mobile_#_LT_txt", "AccountsPage", AreaCode+PhoneNumber);
		hardWait(1);
	}

	public void type_Email() {
		writeTextInto("Person_Email_LT_txt", "AccountsPage", DataIO.get("PersonEmail", "AccountsTestData"));
		hardWait(1);
	}
	public void click_Save_button() {
		click("Save_button_LT", "AccountsPage");
		hardWait(2);
	}

	public boolean verify_User_Created() {
		String Person_Account_Name = DataIO.get("PersonFirstName", "TempTestData") + " " + DataIO.get("PersonLastName", "TempTestData");
		String PersonDOB = DataIO.get("PersonDOB", "TempTestData");
		hardWait(2);
		String AccName = driver.findElement(By.xpath("(//*[@class='entityNameTitle'])/following-sibling::*/span")).getText();
		if(AccName.equalsIgnoreCase(Person_Account_Name)!=true) 
		{
		return false;
		} else {
			System.out.println("Person Account Created: " + Person_Account_Name + " DOB: " + PersonDOB);
			DataIO.updateDataInPropertiesFile("PatientAccountName", Person_Account_Name, "TempTestData");
		    hardWait(2);
			return true;
		}	
	}

	public void pageCleanUp() {
		List <WebElement> openTabs = driver.findElements(By.xpath("//button[contains(.,'Close ')]"));
		int numberofTabs = openTabs.size();
		System.out.println("Number of  Tabs open: " + numberofTabs);
		for(int i=0; i<numberofTabs; i++) {
			driver.findElement(By.xpath("//button[contains(.,'Close ')]")).click();
			hardWait(1);
		}

	}
}
