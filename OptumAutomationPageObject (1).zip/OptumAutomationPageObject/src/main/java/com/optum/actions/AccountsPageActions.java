package com.optum.actions;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.optum.utilities.DataIO;

/**
 * @author Igor Verkhosh - September 2018
 */
public class AccountsPageActions extends BaseActions{

	public WebDriver driver;
	
	public AccountsPageActions(WebDriver driver){
		super(driver);
		this.driver = driver;
	}
	
	//************************************************************
		public void createNewPersonAccount() {
		    click_on_Tab("Accounts_tab");
		    Click_on_New_Account_button();
		    Select_Record_Type_dropdown("Person Account");
		    click_Continue_button();
		    type_FirstName();
		    type_LastName();
		    selectSourceData(); // ScriptMed only at this time/if IRIS selected enter IRIS Account Number
			type_DOB (randomDOB());
			select_Gender();
			type_Phone_Num ();
			type_Mobile_Num ();
			type_Email ();
		    click_Save_button();
		    verify_User_Created();
		    hardWait(2);		
		}
	/*** To select any account which is liested in accounts page list 
	 * @param userName */
	
	public void select_Given_User_From_UsersList(String userName){
		click("accountName_lnk", "AccountsPage", userName);
	}
	
	public void Click_on_New_Account_button() {
		click("New_button", "AccountsPage");
	}

	public void Select_Record_Type_dropdown(String RecordTypeName) {
		selectOptionByVisibleText("AccountRecordType", "AccountsPage", RecordTypeName);
		
	}

	public void click_Continue_button() {
		click("Continue_button", "AccountsPage");
		
	}

	public void type_FirstName() {
		String FirstName = DataIO.get("FirstName", "AccountsTestData")+(addRandomNumberToString(9999));
		DataIO.updateDataInPropertiesFile("PersonFirstName", FirstName, "TempTestData");
		writeTextInto("FirstName_txtbox", "AccountsPage", FirstName);
		
	}
	
	public void type_LastName() {
		String LastName = DataIO.get("LastName", "AccountsTestData") + (addRandomNumberToString(99999)); 
		DataIO.updateDataInPropertiesFile("PersonLastName", LastName, "TempTestData");
		writeTextInto("LastName_txtbox", "AccountsPage", LastName);
		
	}
	// if IRIS selected enter IRIS Account Number
	public void selectSourceData() {
		
		String SourceData = null;
		String CustomerNumber = null;
		String ScriptMedPatientID = "SM";
		int SourceDataSelection = 2; //ScriptMed only at this time// (int) Math.round(Math.random());

		if (SourceDataSelection != 1) {
			SourceData = "IRIS";
			CustomerNumber = addRandomNumberToString(89999999);
			System.out.println("SourceData: " + SourceData);
			System.out.println("Customer Number: " + CustomerNumber);
			selectOptionByVisibleText("SourceData_dropdown", "AccountsPage", SourceData);
			writeTextInto("IRIS_Acc_Num_txtbox", "AccountsPage", CustomerNumber);
		}else {
			SourceData = "ScriptMed";
			ScriptMedPatientID = ScriptMedPatientID + addRandomNumberToString(89999999);
			System.out.println("SourceData: " + SourceData);
			System.out.println("ScriptMed Patient ID: " + ScriptMedPatientID);
			selectOptionByVisibleText("SourceData_dropdown", "AccountsPage", SourceData);
			writeTextInto("ScriptMedPatientID", "AccountsPage", ScriptMedPatientID);
		}		
	}
	
	public void type_DOB(String randomDOB) {
		writeTextInto("DateOfBirth_txt", "AccountsPage", randomDOB);
		DataIO.updateDataInPropertiesFile("PersonDOB", randomDOB, "TempTestData");
	}

	public void select_Gender() {
		int GenderSelection = (int) Math.round(Math.random());
		String Gender;
		if (GenderSelection != 1) {
			Gender = "Male";
		} else
			Gender = "Female";

		selectOptionByVisibleText("Gender_dropdown", "AccountsPage", Gender);
	}

	public void type_Phone_Num() {
		String AreaCode = addRandomNumberToString(899);
		String PhoneNumber = addRandomNumberToString(8999999);
		writeTextInto("PhoneNumber_txt", "AccountsPage", AreaCode+PhoneNumber);
	}
	
	public void type_Mobile_Num() {
		String AreaCode = addRandomNumberToString(899)+100;
		String PhoneNumber = addRandomNumberToString(8999999);
		writeTextInto("Mobile_#_txt", "AccountsPage", AreaCode+PhoneNumber);
	}

	public void type_Email() {
		writeTextInto("Person_Email_txt", "AccountsPage", DataIO.get("PersonEmail", "AccountsTestData"));
	}

	public boolean verify_User_Created() {
		String Person_Account_Name = DataIO.get("PersonFirstName", "TempTestData") + " " + DataIO.get("PersonLastName", "TempTestData");
		String PersonDOB = DataIO.get("PersonDOB", "TempTestData");
		System.out.println("Person Account Created: " + Person_Account_Name + " DOB: " + PersonDOB);
		DataIO.updateDataInPropertiesFile("PatientAccountName", Person_Account_Name, "TempTestData");
		return isElementPresent("Person_Account_Name", "AccountsPage", Person_Account_Name);
	}

	public void click_Save_button() {
		click("Save_button", "AccountsPage");
	}

	public void readTasksList() {
		hardWait(1);
		if (isElementPresent("Tasks_List_Footer", "AssessmentPage")) {
			scrollDownTo("Go_To_Tasks_List_link", "AssessmentPage");
			click("Go_To_Tasks_List_link", "AssessmentPage");
			hardWait(2);
			WebElement taskTable = getElementWithoutWait("Tasks_List_table", "AssessmentPage");
			List<WebElement> taskTableRows = taskTable.findElements(By.tagName("tr"));
			readTaskCreated(taskTableRows);		
		}else {
			scrollDownTo("Account_Tasks_List", "AssessmentPage");
			List<WebElement> taskTableRows = getElementsWithoutWait("Account_Tasks_List", "AssessmentPage");//taskTable.findElements(By.tagName("tr"));
			readTaskCreated(taskTableRows);		
		}
		hardWait(2);
	}
	
	public void readTaskCreated(List<WebElement> taskTableRows) {
		int NumberOfTasksCreated = taskTableRows.size();
		if (NumberOfTasksCreated <= 2) {
			pagerefresh();
			hardWait(1);
			List<WebElement> taskTableRowsAfterRefresh = getElementsWithoutWait("Account_Tasks_List", "AssessmentPage");
			NumberOfTasksCreated = taskTableRowsAfterRefresh.size();
			hardWait(1);
		}
		System.out.println("Number of Tasks Created for this Assessment: " + (NumberOfTasksCreated-1));
		hardWait(2);
		int TableRow = 2;
		for(WebElement taskTableRow:taskTableRows) {
			if (NumberOfTasksCreated > 6) {
				String xPathExpression = "//*[@id='bodyCell']//tr[" + TableRow  +"]/td[3]";
				System.out.println(taskTableRow.findElement(By.xpath(xPathExpression)).getText());	
			} else {
			String xPathExpression = "//*[@id[contains(.,'Bd_body')]]//tr[" + TableRow  +"]/td[3]";
			System.out.println(taskTableRow.findElement(By.xpath(xPathExpression)).getText());	
			}
			TableRow++;
			if (TableRow > NumberOfTasksCreated) {
				break;
			}
		}
	}

}
