package com.optum.actions;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import com.optum.utilities.BasePage;
import com.optum.utilities.DataIO;

public class PrescriptionPageActions extends BaseActions {
	
	public WebDriver driver;

	public PrescriptionPageActions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void addNewPrescription() {
		clickNewPrescription();
		selectPrescriptionStatus("Scheduled");
		selectSourceRx(); // this include pharmacy code and typeRx_Referal_Number("Rx number or Scriptmed Referral number");
		selectDrugTherapy();
		selectPrescriberContact("PrescriberContact");
		selectMedication_Strenght(); //ENBREL SURECLICK 50MG/ML 9 / XELJANZ XR TAB 11MG / VERZENIO TAB 50MG / GAMASTAN S/D INJ 2ML / HCG INJ 10000U
		writeTextIntoSIG();
		writeTextIntoQuantity();
		writeTextIntoRefils();
		selectTreatmentExperienceStatus();
		click_Save_button();
		hardWait(1);
		Assert.assertTrue(verify_Prescription_Created());
		hardWait(2);

	}
	
	public void addNewPrescriptionToExistingPatient() {
		searchForPatient();
		clickNewPrescription();
		selectPrescriptionStatus("Scheduled");
		selectSourceRx(); // this include pharmacy code and typeRx_Referal_Number("Rx number or Scriptmed Referral number");
		selectDrugTherapy();
		selectPrescriberContact("PrescriberContact");
		selectMedication_Strenght(); //ENBREL SURECLICK 50MG/ML 9 / XELJANZ XR TAB 11MG / VERZENIO TAB 50MG / GAMASTAN S/D INJ 2ML / HCG INJ 10000U
		writeTextIntoSIG();
		writeTextIntoQuantity();
		writeTextIntoRefils();
		selectTreatmentExperienceStatus();
		click_Save_button();
		Assert.assertTrue(verify_Prescription_Created());
		hardWait(2);
	}
	public void searchForPatient() {
		String SearchString = DataIO.get("PatientAccountName", "TempTestData");
		search_for_GlobalSearch(SearchString);
		hardWait(2);
		click("accountName_lnk","AccountsPage", SearchString);
	}

	public void clickNewPrescription() {
		click("NewPrescription_button", "AccountsPage");
	}
	
	public void selectPrescriptionStatus(String PrescriptionStatus) {
		selectOptionByVisibleText("PrescriptionStatus_dropbox", "PrescriptionPage", PrescriptionStatus);
	}

	public void selectSourceRx() {
		String SourceRx = null;
		String RxNumber = null;
		String ScriptMedReferalNum = null;
		
		int SourceDataSelection = 1; //(int) Math.round(Math.random());
		
		if (SourceDataSelection != 1) {
			SourceRx = "IRIS";
			RxNumber = addRandomNumberToString(89999999);
			System.out.println("SourceRx: " + SourceRx + " Rx Number: " + RxNumber);
			selectOptionByVisibleText("SourceRx_dropbox", "PrescriptionPage", SourceRx);
			writeTextInto("RxNumber_txtbox", "PrescriptionPage", RxNumber);
		}else {
			SourceRx = "ScriptMed";
			RxNumber = addRandomNumberToString(89999999);
			ScriptMedReferalNum = addRandomNumberToString(89999999);
			System.out.println("SourceRx: " + SourceRx + " ScriptMed Referal Number: " + ScriptMedReferalNum);
			selectOptionByVisibleText("SourceRx_dropbox", "PrescriptionPage", SourceRx);
			hardWait(1);
			selectPharmacyCode();	
			writeTextInto("RxNumber_txtbox", "PrescriptionPage", RxNumber);
			writeTextInto("ScriptMedReferalNumber_txt", "PrescriptionPage", ScriptMedReferalNum);
		}

	}

	public void selectPrescriber(String Prescriber) {
		writeTextInto("Prescriber_Info_txt", "PrescriptionPage", DataIO.get(Prescriber, "PrescriptionTestData"));
		hardWait(1);
		String winHandleParent = driver.getWindowHandle();
		click("Prescriber_Contact_lookup", "PrescriptionPage");
		hardWait(1);
		switchwindow(winHandleParent);
		hardWait(1);
		click("Lookup_Go_btn", "PrescriptionPage", Prescriber);
		switchToFramebyIndex(1);
		click("Prescriber_Contact_Link", "PrescriptionPage", Prescriber);
		hardWait(1);
		driver.switchTo().window(winHandleParent);

	}
	
	public void selectPrescriberContact(String Prescriber) {
		writeTextInto("Prescriber_Contact_txt", "PrescriptionPage", DataIO.get(Prescriber, "PrescriptionTestData"));
		hardWait(1);
//		String winHandleParent = driver.getWindowHandle();
//		click("Prescriber_Contact_lookup", "PrescriptionPage");
//		hardWait(1);
//		switchwindow(winHandleParent);
//		hardWait(1);
//		click("Lookup_Go_btn", "PrescriptionPage", Prescriber);
//		switchToFramebyIndex(1);
//		click("Prescriber_Contact_Link", "PrescriptionPage", Prescriber);
//		hardWait(1);
//		driver.switchTo().window(winHandleParent);

	}
	
	// Selecting Pharmacy Code based on the drop-down box size - need clear identification of the drop-box
	public void selectPharmacyCode() {
		hardWait(2);
		long PharmacyCodeIndex = addRandomNumber(27);
		if (PharmacyCodeIndex==0) {
			PharmacyCodeIndex = PharmacyCodeIndex+1;
		}
		selectOptionByIndex("PharmacyCode_dropbox", "PrescriptionPage", (int) PharmacyCodeIndex);
	}
	
	private void selectDrugTherapy() {
		writeTextInto("DrugTherapy_txt", "PrescriptionPage", DataIO.get("DrugTherapy", "PrescriptionTestData"));
		
	}

	public void selectMedication_Strenght() {
		writeTextInto("Med_and_Strenght_txt", "PrescriptionPage",getMedicationStrenght());
	}

	public void writeTextIntoSIG() { //"Take one tabled by mouse every day"
		writeTextInto("SIG_txtbox", "PrescriptionPage", DataIO.get("SIG_text", "PrescriptionTestData"));
	}
	
	public void writeTextIntoQuantity() { //60
		writeTextInto("Quantity_txtbox", "PrescriptionPage", DataIO.get("Quantity_text", "PrescriptionTestData"));
	}
	public void writeTextIntoRefils() { //2
		writeTextInto("Refils_txtbox", "PrescriptionPage", DataIO.get("Refils_text", "PrescriptionTestData"));
	}
	
	public void selectTreatmentExperienceStatus() {
		
	}
	
	public void click_Save_button() {
		click("Save_button", "AccountsPage");
	}

	/* Verify Prescription Created / Added to a person */
	public boolean verify_Prescription_Created() {
		hardWait(1);
		String Prescription_Number = getText("Prescription_Number", "PrescriptionPage");
		if (Prescription_Number.equalsIgnoreCase("New Prescription")) {
			System.out.println("Prescription is not created");
			Reporter.log("Prescription is not created");
			return false;
		} else {
			System.out.println("Prescription " + Prescription_Number + " created");
			Reporter.log("Prescription " + Prescription_Number + " created");
			return true;
		}
	}

	/* To select getMedicationStrenght from data file */
	public String getMedicationStrenght() {
		int Med_Strenght = random(1,5);
		String Medication_Strenght = null;
		Medication_Strenght = DataIO.get("Medication_Strenght_" + Med_Strenght, "PrescriptionTestData");
		return Medication_Strenght;
	}
	


}
