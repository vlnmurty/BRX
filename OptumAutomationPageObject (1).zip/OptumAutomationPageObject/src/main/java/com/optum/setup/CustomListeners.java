//package com.optum.setup;
//
//import org.testng.ISuite;
//import org.testng.ISuiteListener;
//import org.testng.ITestContext;
//import org.testng.ITestListener;
//import org.testng.ITestResult;
//import org.testng.Reporter;
//import com.optum.setup.BaseTest;
//import com.optum.setup.Screenshot;
//import com.relevantcodes.extentreports.LogStatus;
//
//
//public class CustomListeners extends BaseTest implements ITestListener,ISuiteListener {
//
//	public 	String messageBody;
//	
//	public void onFinish(ITestContext arg0) {	
//	}
//
//	public void onStart(ITestContext arg0) {	
//	}
//
//	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {	
//	}
//
//	public void onTestFailure(ITestResult arg0) {
//
//		System.setProperty("org.uncommons.reportng.escape-output","false");
//		Screenshot.screenShotOnTestFail(arg0);
//		
//		Screenshot.screenShotOnTestFail(arg0);
//		tsi.test.log(LogStatus.FAIL, arg0.getTestName().toUpperCase() + " FAILED");
//		tsi.test.log(LogStatus.FAIL, arg0.getName().toUpperCase()+" Failed with exception : "+arg0.getThrowable());
//		tsi.test.log(LogStatus.FAIL, tsi.test.addScreenCapture(Screenshot.screenshotName));
//		
//		
//		
//		Reporter.log("Click to see Screenshot");
//		Reporter.log("<a target=\"_blank\" href="+Screenshot.screenshotName+">Screenshot</a>");
//		Reporter.log("<br>");
//		Reporter.log("<br>");
//		Reporter.log("<a target=\"_blank\" href="+Screenshot.screenshotName+"><img src="+Screenshot.screenshotName+" height=200 width=200></img></a>");
//		tsi.extentReports.endTest(tsi.test);
//		tsi.extentReports.flush();
//		
//	}
//
//	public void onTestSkipped(ITestResult arg0) {
//		tsi.test.log(LogStatus.SKIP, arg0.getName().toUpperCase()+" Skipped the test as the Run mode is NO");
//		tsi.extentReports.endTest(tsi.test);
//		tsi.extentReports.flush();		
//	}
//
//
//	public void onTestStart(ITestResult arg0) {
//		tsi.test = tsi.extentReports.startTest(arg0.getName().toUpperCase());
//	}
//
//	public void onTestSuccess(ITestResult arg0) {
//		tsi.test.log(LogStatus.PASS, arg0.getName().toUpperCase()+" PASS");
//		tsi.extentReports.endTest(tsi.test);
//		tsi.extentReports.flush();
//		
//	}
//
//	public void onFinish(ISuite arg0) {
//	}
//
//	public void onStart(ISuite arg0) {
//		
//	}
//
//}
