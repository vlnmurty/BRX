package roughTests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.optum.setup.BaseTest;
import com.optum.utilities.DataIO;

public class ReadTasksNames extends BaseTest{

	@AfterClass
	public void RefreshSession(){
		tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
	}
	
	@BeforeTest
	public void getStartTime() {
		tsi.baseAction.getStartTime();
	}
	
	@Test
	public void ReadTasksCreated() {
		searchAndOpenCreatedAssessment();
		openAssessmentPatientAccount();
		readTasksList();
	}
	
	private void searchAndOpenCreatedAssessment() {
		String SearchString = DataIO.get("AssesmentName", "TempTestData");
		tsi.baseAction.search_for_GlobalSearch(SearchString);
		tsi.baseAction.hardWait(2);
		tsi.baseAction.click("accountName_lnk","AccountsPage", SearchString);

	}

	public void openAssessmentPatientAccount() {
		tsi.baseAction.click("PatientAccountName_link", "AssessmentPage");
		tsi.baseAction.hardWait(2);
		
	}
	
	public void readTasksList() {
		if (tsi.baseAction.isElementPresent("Tasks_List_Footer", "AssessmentPage")) {
			tsi.baseAction.click("Go_To_Tasks_List_link", "AssessmentPage");
			tsi.baseAction.hardWait(2);
			WebElement taskTable = tsi.baseAction.getElementWithoutWait("Tasks_List_table", "AssessmentPage");
			List<WebElement> taskTableRows = taskTable.findElements(By.tagName("tr"));
//			List<WebElement> taskTableRows = tsi.baseAction.getElementsWithoutWait("Account_Tasks_List", "AssessmentPage");
			readTaskCreated(taskTableRows);		
		}else {
			List<WebElement> taskTableRows = tsi.baseAction.getElementsWithoutWait("Account_Tasks_List", "AssessmentPage");//taskTable.findElements(By.tagName("tr"));
			readTaskCreated(taskTableRows);		
		}
		tsi.baseAction.hardWait(2);
	}
	
	public void readTaskCreated(List<WebElement> taskTableRows) {
		int NumberOfTasksCreated = taskTableRows.size();
		System.out.println("Number of Tasks Created for this Assessment: " + (NumberOfTasksCreated-1));
		tsi.baseAction.hardWait(2);
		int TableRow = 2;
		for(WebElement taskTableRow:taskTableRows) {
			if (NumberOfTasksCreated > 6) {
				String xPathExpression = "//*[@id='bodyCell']//tr[" + TableRow  +"]/td[3]";
				System.out.println(taskTableRow.findElement(By.xpath(xPathExpression)).getText());	
			} else {
			String xPathExpression = "//*[@id[contains(.,'Bd_body')]]//tr[" + TableRow  +"]/td[3]";
			System.out.println(taskTableRow.findElement(By.xpath(xPathExpression)).getText());	
			}
			TableRow++;
			if (TableRow > NumberOfTasksCreated) {
				break;
			}
		}
	}
//		tsi.baseAction.click("Go_To_Tasks_List_link", "AssessmentPage");
//		tsi.baseAction.hardWait(2);
//		WebElement taskTable = tsi.baseAction.getElementWithoutWait("Tasks_List_table", "AssessmentPage");
//		//int NumberOfTasksRow = taskTable.;
//		List<WebElement> taskTableRows = taskTable.findElements(By.tagName("tr"));
//		int NumberOfTasksCreated = taskTableRows.size();
//		System.out.println("Number of Tasks Created for this Assessment: " + (NumberOfTasksCreated-1));
//		tsi.baseAction.hardWait(2);
//		int TableRow = 2;
//		for(WebElement taskTableRow:taskTableRows) {
//			String xPathExpression = "//*[@id='bodyCell']//tr[" + TableRow  +"]/td[3]";
//			System.out.println(taskTableRow.findElement(By.xpath(xPathExpression)).getText());
//			TableRow++;
//			if (TableRow > NumberOfTasksCreated) {
//				break;
//			}
//		}

	@AfterTest
	public void getEndTime() {
		tsi.baseAction.getEndTime();
	}
}
