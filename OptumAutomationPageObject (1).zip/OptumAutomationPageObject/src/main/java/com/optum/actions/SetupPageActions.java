package com.optum.actions;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.optum.actions.BaseActions;

public class SetupPageActions extends BaseActions{

	WebDriver driver;
	public SetupPageActions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public void Open_User_Profiles_Object() {
		click("Logged_User_Link","SetupPage");
		click("User_Setup_Link", "SetupPage");
		click("Manage_Users_Link", "SetupPage");
		click("Profiles_Link", "SetupPage");
		hardWait(3);
	}
	
	public void click_On_Profile_Link(String profileName) {
		if (profileName.equalsIgnoreCase("Support Manager")) {
			click("Support_Manager_Profiles_Name_Link", "SetupPage", profileName);
			hardWait(3);
		}
		else {
			click("Profiles_Name_Link", "SetupPage", profileName);
			hardWait(3);
		}

	}
	
	public void read_Tab_Settings(String profileName) {
		getList_Of_All_Standard_Tabs_Settings_for_Profile("//*[@id='ep']/div[2]/div[19]/table/tbody/tr", "StandardTabsSetting", profileName);
		getList_Of_All_Custom_Tabs_Settings_for_Profile("//*[@id='ep']/div[2]/div[20]/table/tbody/tr", "CustomTabsSetting", profileName);
	}
	

	public void getList_Of_All_Standard_Tabs_Settings_for_Profile(String xpathLocator, String FileName, String ProfileName) {

		waitForLoad(driver);
		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested"
				+ File.separator + FileName + "_" + ProfileName + ".csv";
		int rowCount = driver.findElements(By.xpath(xpathLocator)).size();	
		System.out.println("Total Number of Rows in Section: " + rowCount);
		StringBuffer data = new StringBuffer();
		try {

			FileOutputStream fos = new FileOutputStream(filePath);
			data.append("Tab Name" + "," + "Tab Visibility" + "," + "Tab Name" + "," + "Tab Visibility"+ '\n');
			int i;
			for ( i =2; i <= rowCount; i++) {
				String standardTab1 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[19]/table/tbody/tr[" + i + "]/td[1]")).getText();
				String standardTab2 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[19]/table/tbody/tr[" + i + "]/td[2]")).getText();
				String standardTab3 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[19]/table/tbody/tr[" + i + "]/td[3]")).getText();
				String standardTab4 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[19]/table/tbody/tr[" + i + "]/td[4]")).getText();
					System.out.println("Tab Name: " + standardTab1 + " Visibility " +standardTab2 + " Tab Name: " + standardTab3 + " Visibility " + standardTab4 );
					data.append(standardTab1 + "," + standardTab2 + "," + standardTab3 +"," + standardTab4 + '\n');
			}
			// For storing data into CSV files
			fos.write(data.toString().getBytes());
			fos.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
	public void getList_Of_All_Custom_Tabs_Settings_for_Profile(String xpathLocator, String FileName, String ProfileName) {

		waitForLoad(driver);
		String filePath = System.getProperty("user.dir") + File.separator + "resources" + File.separator + "FilesTested"
				+ File.separator + FileName + "_" + ProfileName + ".csv";
		int rowCount = driver.findElements(By.xpath(xpathLocator)).size();
		System.out.println("Total Number of Rows in Section: " + rowCount);
		StringBuffer data = new StringBuffer();
		try {

			FileOutputStream fos = new FileOutputStream(filePath);
			data.append("Tab Name" + "," + "Tab Visibility" + "," + "Tab Name" + "," + "Tab Visibility"+ '\n');
			int i;
			for ( i =2; i <= rowCount; i++) {
				String customTab1 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[20]/table/tbody/tr[" + i + "]/td[1]")).getText();
				String customTab2 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[20]/table/tbody/tr[" + i + "]/td[2]")).getText();
				String customTab3 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[20]/table/tbody/tr[" + i + "]/td[3]")).getText();
				String customTab4 = driver.findElement(By.xpath("//*[@id='ep']/div[2]/div[20]/table/tbody/tr[" + i + "]/td[4]")).getText();
					System.out.println("Tab Name: " + customTab1 + " Visibility " +customTab2 + " Tab Name: " + customTab3 + " Visibility " + customTab4 );
					data.append(customTab1 + "," + customTab2 + "," + customTab3 +"," + customTab4 + '\n');
			}
			// For storing data into CSV files
			fos.write(data.toString().getBytes());
			fos.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

	}
}