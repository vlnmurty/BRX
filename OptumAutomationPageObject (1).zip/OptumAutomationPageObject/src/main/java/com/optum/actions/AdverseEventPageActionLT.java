package com.optum.actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class AdverseEventPageActionLT extends BaseActions {

	public WebDriver driver;

	public AdverseEventPageActionLT(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void readFrameElements() {
		List<WebElement> pageElements = driver.findElements(By.xpath("//label"));
		List<WebElement> pageButtons = driver.findElements(By.xpath("//button"));
		List<WebElement> pageSelects = driver.findElements(By.xpath("//label//select"));
		int ElemOnPage = pageElements.size();
		int ButtonsOnPage = pageButtons.size();
		int SelectsOnPage = pageSelects.size();
		System.out.println("Number of Element on Page: " + ElemOnPage);
		System.out.println("Number of Buttons on Page: " + ButtonsOnPage);
		System.out.println("Number of Buttons on Page: " + SelectsOnPage);
		if (ElemOnPage > 0) {
			for (WebElement foundElement : pageElements) {
				String eleName = foundElement.getText();
				String tagName = foundElement.getTagName();
				System.out.println(eleName + " - " + tagName);
				if (eleName.contains("lbs") != false) {
					Select dropdown = new Select(foundElement);
					dropdown.selectByVisibleText("lbs");
					driver.findElement(By.xpath("//button")).click();
					hardWait(1);
				}
				hardWait(1);
			}
		}
	}		

	public void addNewAdverseEvent_LT() {
		
		// click (new_Adverse_Event_LT_button);
		hardWait(2);
		List<WebElement> links =driver.findElements(By.tagName("a"));
		int LinksOnPage = links.size();
		System.out.println("Number of Links on the Page: " +LinksOnPage);
		for (WebElement numOfLinks:links) {
			if(numOfLinks.getText().equalsIgnoreCase("") != true) {
				if (numOfLinks.getText().equalsIgnoreCase("New Adverse Event") != false) {
					numOfLinks.click();
					break;
				}
			}
		}	
		hardWait(1);
	
		// find all your iframes
		List<WebElement> iframes = driver.findElements(By.xpath("//iframe[contains(@id,'vfFrameId_')]"));
		// print your number of frames
		System.out.println("Total Number of Frames: " + iframes.size());
		if (iframes.size() > 0) {
			// you can reach each frame on your site
			for (WebElement iframeName : iframes) {
				// switch to every frame
				System.out.println("frameid: " + iframeName.getAttribute("name"));
				driver.switchTo().frame(iframeName.getAttribute("name"));
				List<WebElement> pageButtons = driver.findElements(By.xpath("//button"));
		        List<WebElement> pageSelects = driver.findElements(By.xpath("//label//select"));
				int ElemOnPage = pageSelects.size();
				int ButtonsOnPage = pageButtons.size();
				System.out.println("Number of DropDowns on Page: " + pageSelects);
				System.out.println("Number of Buttons on Page: " + ButtonsOnPage);
				if (ElemOnPage > 0) {
					for (WebElement foundElement : pageSelects) {
						// Page 1 of 6
						String eleName = foundElement.getText();
						System.out.println("Element Name - " + eleName);
				    	if (eleName.contains("lbs") != false ) {
				    		Select dropdown = new Select(foundElement);
				    		dropdown.selectByVisibleText("lbs");
				    		driver.findElement(By.xpath("//button")).click();		
				    		hardWait(1);
				    	}
				    	hardWait(1);
					}
					// Page 2 of 6

					driver.findElement(By.xpath("//label[contains(., 'Adverse Event')]")).click();
					driver.findElement(By.xpath("//label[contains(., 'Date of Event')]")).sendKeys("11/01/2018");
					driver.findElement(By.xpath("//label[contains(., 'Describe Event, Problem, or Product Use Error')]")).sendKeys("Test Automation");
					driver.findElement(By.xpath("//label[contains(., 'No')]")).click();
					driver.findElement(By.xpath("//label[contains(., 'Returned to Manufacturer')]")).click();
					driver.findElement(By.xpath("//label[contains(., 'Returned to Manufacturer Date')]")).sendKeys("11/01/2018");
					driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
					hardWait(1);
					
					// Page 3 of 6
					List<WebElement> pageSelects3 = driver.findElements(By.xpath("//label//select"));
					for (WebElement foundElement : pageSelects3) {
						String eleName = foundElement.getText();
						System.out.println("Element Name - " + eleName);
				    	if (eleName.contains("Daily") != false ) {
				    		Select dropdown = new Select(foundElement);
				    		dropdown.selectByVisibleText("Daily");	
				    		hardWait(1);
				    	} else if (eleName.contains("Oral") != false ) {
				    		Select dropdown = new Select(foundElement);
				    		dropdown.selectByVisibleText("Oral");	
				    		hardWait(1);
				    	}

					}
			    	hardWait(1);
					driver.findElement(By.xpath("//label[contains(., 'From')]")).sendKeys("11/01/2018");
					driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
					// Page 4 of 6
			    	hardWait(1);
			    	driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
					// Page 5 of 6
			    	hardWait(1);
			    	driver.findElement(By.xpath("//label[contains(., 'Pharmacist')]")).click();
//			    	driver.findElement(By.xpath("//*[@value[contains(., 'Pharmacist')]]")).click();
			    	driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
					// Page 6 of 6
			    	hardWait(1);
			    	driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
					// All actions inside this if method
			    	hardWait(1);
			    	driver.findElement(By.xpath("//label[contains(., 'SUBMIT')]")).click();
			    	driver.findElement(By.xpath("//button[contains(., 'Next')]")).click();
				}
		    	hardWait(1);
				driver.switchTo().defaultContent();
			}
		} else
			System.out.println("can not find any frame in HTML");
		        
		hardWait(1);       
	}

}
