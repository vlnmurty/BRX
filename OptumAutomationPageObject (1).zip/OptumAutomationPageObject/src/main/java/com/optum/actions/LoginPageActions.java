package com.optum.actions;

import org.openqa.selenium.WebDriver;

/**
 * @author Igor Verkhosh - September 2018
 *
 */
public class LoginPageActions extends BaseActions{

	public WebDriver driver;
	
	public LoginPageActions(WebDriver driver){
		super(driver);
		this.driver = driver;
	}	 

	/**
	 * This method is to login in Optum Salesforce Org
	 */
	
	public void PERFORM_LOGIN_IN_OPTUM(String userName, String password){
		 //Enter User Name into textBox
		 writeTextInto("loginUserName_box", "LoginPage", userName);	 
		 //Enter password into textBox
		 writeTextInto("loginPassword_box", "LoginPage", password);	 
		 //Clicking on login Button
		 click("loginButton", "LoginPage");	 
		 //move and click Mouse to dismiss Google security
		 hardWait(1);
		 if( driver.getWindowHandle() == "") {
			 mouseClickOnFooter();
		 }

	}

	public void verify_Home_Page_Displayed(String userName, String password){
		 //Enter User Name into textBox
		 writeTextInto("loginUserName_box", "LoginPage", userName);
		 
		 //Enter password into textBox
		 writeTextInto("loginPassword_box", "LoginPage", password);
		 
		 //Clicking on login Button
		 click("loginButton", "LoginPage");
	}
}
