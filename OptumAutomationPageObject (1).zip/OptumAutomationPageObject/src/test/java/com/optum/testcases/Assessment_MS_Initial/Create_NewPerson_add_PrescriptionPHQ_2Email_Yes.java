package com.optum.testcases.Assessment_MS_Initial;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.optum.setup.BaseTest;

public class Create_NewPerson_add_PrescriptionPHQ_2Email_Yes extends BaseTest {

	@AfterClass
	public void RefreshSession() {
		tsi.baseAction.refeshLaunchingURL("ApplicationLaunchingURL", "TempTestData", this.getClass().getSimpleName());
		tsi.baseAction.getEndTime();
	}

	@BeforeClass
	public void getStartTime() {
		tsi.baseAction.getStartTime();
	}

	@Test  //(priority = 1, enabled = true, invocationCount = 1)
	public void create_New_Person_Account() {
		tsi.accountPage.createNewPersonAccount();
	}

	@Test (dependsOnMethods= "create_New_Person_Account")//(priority = 2, enabled = true, invocationCount = 1)
	public void addNewPrescription() {
		tsi.prescriptionPage.addNewPrescription();
	}

//	@Test (dependsOnMethods= "addNewPrescription")//(priority = 3, enabled = true, invocationCount = 1)
//	public void createNewAssessment() {
//		tsi.assessmentPage.createNewAssessment("1", "1", "Yes");
//	}
//
//	@Test (dependsOnMethods= "createNewAssessment") //(priority = 4, enabled = true, invocationCount = 1)
//	public void verifyCreatedTasks() {
//		tsi.assessmentPage.openAssessmentPatientAccount();
//		tsi.accountPage.readTasksList();
//	}

}